#ifndef ROBOCALC_ROBOT_ARMPLATFORM_H_
#define ROBOCALC_ROBOT_ARMPLATFORM_H_

#include "DataTypes.h"

class armPlatform {
public:
	armPlatform() = default; 
	virtual ~armPlatform() = default;
	virtual void Sense() {};
	virtual void Actuate() {};
	
	virtual void pick() = 0;
	virtual void drop() = 0;
	virtual void lift() = 0;
	virtual void lower(double dist) = 0;
	virtual void set_v_theta(double v_t) = 0;
	virtual void set_v_radius(double v_r) = 0;

	virtual bool shouldTriggerRShapeTS() = 0;
	virtual std::tuple<double> getRShapeTSArgs() = 0;

	virtual bool shouldTriggerLShapeY() = 0;
	virtual std::tuple<double> getLShapeYArgs() = 0;

	virtual bool shouldTriggerLShapeTS() = 0;
	virtual std::tuple<double> getLShapeTSArgs() = 0;

	virtual bool shouldTriggerRShapeY() = 0;
	virtual std::tuple<double> getRShapeYArgs() = 0;

	virtual bool shouldTriggerLifted_TS() = 0;
	virtual std::tuple<double> getLifted_TSArgs() = 0;

	virtual bool shouldTriggerLShapeX() = 0;
	virtual std::tuple<double> getLShapeXArgs() = 0;

	virtual bool shouldTriggerRShapeX() = 0;
	virtual std::tuple<double> getRShapeXArgs() = 0;
};

#endif
