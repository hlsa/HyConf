#ifndef ROBOCALC_CONTROLLERS_ARMCONTROLLER_H_
#define ROBOCALC_CONTROLLERS_ARMCONTROLLER_H_

#include "armPlatform.h"
#include "RoboCalcAPI/Controller.h"
#include "DataTypes.h"

#include "detectionBehaviourStm.h"

class armController: public robocalc::Controller 
{
public:
	armController(armPlatform& _robot) : robot(&_robot){};
	armController() : robot(nullptr){};
	
	~armController() = default;
	
	void Execute()
	{
		detectionBehaviourStm.execute();
	}
	
	struct Channels
	{
		armController& instance;
		Channels(armController& _instance) : instance(_instance) {}
		
		EventBuffer* tryEmitLifted_TS(void* sender, std::tuple<double> args)
		{
			if(instance.detectionBehaviourStm.canReceiveLifted_TS(args))
				instance.detectionBehaviourStm.lifted_TS_in.trigger(sender, args);
				
			return &instance.detectionBehaviourStm.lifted_TS_in;
		}
		
		EventBuffer* tryEmitRShapeX(void* sender, std::tuple<double> args)
		{
			if(instance.detectionBehaviourStm.canReceiveRShapeX(args))
				instance.detectionBehaviourStm.rShapeX_in.trigger(sender, args);
				
			return &instance.detectionBehaviourStm.rShapeX_in;
		}
		
		EventBuffer* tryEmitRShapeY(void* sender, std::tuple<double> args)
		{
			if(instance.detectionBehaviourStm.canReceiveRShapeY(args))
				instance.detectionBehaviourStm.rShapeY_in.trigger(sender, args);
				
			return &instance.detectionBehaviourStm.rShapeY_in;
		}
		
		EventBuffer* tryEmitRShapeTS(void* sender, std::tuple<double> args)
		{
			if(instance.detectionBehaviourStm.canReceiveRShapeTS(args))
				instance.detectionBehaviourStm.rShapeTS_in.trigger(sender, args);
				
			return &instance.detectionBehaviourStm.rShapeTS_in;
		}
		
		EventBuffer* tryEmitLShapeX(void* sender, std::tuple<double> args)
		{
			if(instance.detectionBehaviourStm.canReceiveLShapeX(args))
				instance.detectionBehaviourStm.lShapeX_in.trigger(sender, args);
				
			return &instance.detectionBehaviourStm.lShapeX_in;
		}
		
		EventBuffer* tryEmitLShapeY(void* sender, std::tuple<double> args)
		{
			if(instance.detectionBehaviourStm.canReceiveLShapeY(args))
				instance.detectionBehaviourStm.lShapeY_in.trigger(sender, args);
				
			return &instance.detectionBehaviourStm.lShapeY_in;
		}
		
		EventBuffer* tryEmitLShapeTS(void* sender, std::tuple<double> args)
		{
			if(instance.detectionBehaviourStm.canReceiveLShapeTS(args))
				instance.detectionBehaviourStm.lShapeTS_in.trigger(sender, args);
				
			return &instance.detectionBehaviourStm.lShapeTS_in;
		}
		
	};
	
	Channels channels{*this};
	
private:
	armPlatform* robot;
	detectionBehaviourStm_StateMachine<Channels> detectionBehaviourStm{*robot, channels};
};

#endif
