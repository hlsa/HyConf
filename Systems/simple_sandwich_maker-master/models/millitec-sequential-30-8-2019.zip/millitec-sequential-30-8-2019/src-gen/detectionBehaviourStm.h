#ifndef ROBOCALC_STATEMACHINES_DETECTIONBEHAVIOURSTM_H_
#define ROBOCALC_STATEMACHINES_DETECTIONBEHAVIOURSTM_H_

#include "RoboCalcAPI/StateMachine.h"

#ifndef ROBOCALC_THREAD_SAFE
#define THREAD_SAFE_ONLY(x)
#else
#include <mutex>
#define THREAD_SAFE_ONLY(x) x
#endif

#include "armPlatform.h"
#include "RoboCalcAPI/Timer.h"
#include "Functions.h"
#include "DataTypes.h"
#include <assert.h>
#include <set>
#include "pidOp.h"
#include "interceptOp.h"

using namespace robocalc;
using namespace robocalc::functions;

template<typename Channels>
class detectionBehaviourStm_StateMachine : public StateMachine<armPlatform, detectionBehaviourStm_StateMachine<Channels>>
{
	
	// Clocks and externals
	public:
		armPlatform& robot;
		Channels& controller;
		
					

	// Channels/Event buffers
	public: 	
		class FINDING_FIRST_SHAPE_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit FINDING_FIRST_SHAPE_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for FINDING_FIRST_SHAPE_State_t(stateMachine)"<<std::endl;
				}
				
				FINDING_FIRST_SHAPE_State_t() = delete;
			
				void enter() override
				{
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		class FOUND_FIRST_SHAPE_X_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit FOUND_FIRST_SHAPE_X_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for FOUND_FIRST_SHAPE_X_State_t(stateMachine)"<<std::endl;
				}
				
				FOUND_FIRST_SHAPE_X_State_t() = delete;
			
				void enter() override
				{
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		class FOUND_FIRST_SHAPE_Y_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit FOUND_FIRST_SHAPE_Y_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for FOUND_FIRST_SHAPE_Y_State_t(stateMachine)"<<std::endl;
				}
				
				FOUND_FIRST_SHAPE_Y_State_t() = delete;
			
				void enter() override
				{
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		class FOUND_FIRST_SHAPE_TS_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit FOUND_FIRST_SHAPE_TS_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for FOUND_FIRST_SHAPE_TS_State_t(stateMachine)"<<std::endl;
				}
				
				FOUND_FIRST_SHAPE_TS_State_t() = delete;
			
				void enter() override
				{
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		class FOUND_SECOND_SHAPE_X_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit FOUND_SECOND_SHAPE_X_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for FOUND_SECOND_SHAPE_X_State_t(stateMachine)"<<std::endl;
				}
				
				FOUND_SECOND_SHAPE_X_State_t() = delete;
			
				void enter() override
				{
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		class FOUND_SECOND_SHAPE_Y_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit FOUND_SECOND_SHAPE_Y_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for FOUND_SECOND_SHAPE_Y_State_t(stateMachine)"<<std::endl;
				}
				
				FOUND_SECOND_SHAPE_Y_State_t() = delete;
			
				void enter() override
				{
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		class FOUND_SECOND_SHAPE_TS_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit FOUND_SECOND_SHAPE_TS_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for FOUND_SECOND_SHAPE_TS_State_t(stateMachine)"<<std::endl;
				}
				
				FOUND_SECOND_SHAPE_TS_State_t() = delete;
			
				void enter() override
				{
					this->machine.robot.interceptOp(this->machine.shape1_x, (this->machine.shape1_y) + (((this->machine.shape2_ts) - (this->machine.shape1_ts)) * (this->machine.BELT_SPEED)));
					this->machine.robot.lower(this->machine.HEIGHT_TO_SHAPE1);
					this->machine.robot.pick();
					this->machine.robot.lift();
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		class UNLOAD_ON_SECOND_SHAPE_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit UNLOAD_ON_SECOND_SHAPE_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for UNLOAD_ON_SECOND_SHAPE_State_t(stateMachine)"<<std::endl;
				}
				
				UNLOAD_ON_SECOND_SHAPE_State_t() = delete;
			
				void enter() override
				{
					this->machine.robot.interceptOp(this->machine.shape2_x, (this->machine.shape2_y) + (((this->machine.liftTS) - (this->machine.shape2_ts)) * (this->machine.BELT_SPEED)));
					this->machine.robot.lower(this->machine.HEIGHT_TO_SHAPE2);
					this->machine.robot.drop();
					this->machine.robot.lift();
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		class GO_TO_HOME_POSITION_State_t : public robocalc::State<detectionBehaviourStm_StateMachine<Channels>>
		{
			public:
				explicit GO_TO_HOME_POSITION_State_t(detectionBehaviourStm_StateMachine<Channels>& _sm) 
					: robocalc::State<detectionBehaviourStm_StateMachine<Channels>>(_sm)
				{
					std::cout<<"Constructor for GO_TO_HOME_POSITION_State_t(stateMachine)"<<std::endl;
				}
				
				GO_TO_HOME_POSITION_State_t() = delete;
			
				void enter() override
				{
					this->machine.robot.pidOp(this->machine.HOME_X, this->machine.HOME_Y);
				}
				
				void exit() override
				{
				}
				
				void during() override
				{
				}
		};
		
		FINDING_FIRST_SHAPE_State_t fINDING_FIRST_SHAPE_State{robot, *this};
		FOUND_FIRST_SHAPE_X_State_t fOUND_FIRST_SHAPE_X_State{robot, *this};
		FOUND_FIRST_SHAPE_Y_State_t fOUND_FIRST_SHAPE_Y_State{robot, *this};
		FOUND_FIRST_SHAPE_TS_State_t fOUND_FIRST_SHAPE_TS_State{robot, *this};
		FOUND_SECOND_SHAPE_X_State_t fOUND_SECOND_SHAPE_X_State{robot, *this};
		FOUND_SECOND_SHAPE_Y_State_t fOUND_SECOND_SHAPE_Y_State{robot, *this};
		FOUND_SECOND_SHAPE_TS_State_t fOUND_SECOND_SHAPE_TS_State{robot, *this};
		UNLOAD_ON_SECOND_SHAPE_State_t uNLOAD_ON_SECOND_SHAPE_State{robot, *this};
		GO_TO_HOME_POSITION_State_t gO_TO_HOME_POSITION_State{robot, *this};
		
		EventBuffer* blockedByLifted_TS = nullptr;
		
		inline void tryEmitLifted_TS(std::tuple<double> args)
		{
			blockedByLifted_TS = controller.tryEmitLifted_TS(this, args);
		}
		
		bool canReceiveLifted_TS(std::tuple<double> args)
		{
			if(blockedByLifted_TS != nullptr)
				if(blockedByLifted_TS->getSender() == this)
					return false;
					
			blockedByLifted_TS = nullptr;
			
			switch(currentState)
			{
				case s_FINDING_FIRST_SHAPE:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_TS:
				{
					return true;
					
					
					
					return false;
				}
				case s_UNLOAD_ON_SECOND_SHAPE:
				{
					return true;
					
					
					
					return false;
				}
				case s_GO_TO_HOME_POSITION:
				{
					
					
					
					return false;
				}
				default:
				{
					return false;
				}
			}
		}
		
		struct Lifted_TS_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<double> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<double> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} lifted_TS_in;
		
		EventBuffer* blockedByRShapeX = nullptr;
		
		inline void tryEmitRShapeX(std::tuple<double> args)
		{
			blockedByRShapeX = controller.tryEmitRShapeX(this, args);
		}
		
		bool canReceiveRShapeX(std::tuple<double> args)
		{
			if(blockedByRShapeX != nullptr)
				if(blockedByRShapeX->getSender() == this)
					return false;
					
			blockedByRShapeX = nullptr;
			
			switch(currentState)
			{
				case s_FINDING_FIRST_SHAPE:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_TS:
				{
					{
						const auto& shape2_x = std::get<0>(args);
						if((eT.get()) <= (DELAY_DISCARD))
						{
							this->shape2_x = shape2_x;
							return true;
						}
					}
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_UNLOAD_ON_SECOND_SHAPE:
				{
					
					
					
					return false;
				}
				case s_GO_TO_HOME_POSITION:
				{
					
					
					
					return false;
				}
				default:
				{
					return false;
				}
			}
		}
		
		struct RShapeX_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<double> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<double> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} rShapeX_in;
		
		EventBuffer* blockedByRShapeY = nullptr;
		
		inline void tryEmitRShapeY(std::tuple<double> args)
		{
			blockedByRShapeY = controller.tryEmitRShapeY(this, args);
		}
		
		bool canReceiveRShapeY(std::tuple<double> args)
		{
			if(blockedByRShapeY != nullptr)
				if(blockedByRShapeY->getSender() == this)
					return false;
					
			blockedByRShapeY = nullptr;
			
			switch(currentState)
			{
				case s_FINDING_FIRST_SHAPE:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_X:
				{
					return true;
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_UNLOAD_ON_SECOND_SHAPE:
				{
					
					
					
					return false;
				}
				case s_GO_TO_HOME_POSITION:
				{
					
					
					
					return false;
				}
				default:
				{
					return false;
				}
			}
		}
		
		struct RShapeY_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<double> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<double> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} rShapeY_in;
		
		EventBuffer* blockedByRShapeTS = nullptr;
		
		inline void tryEmitRShapeTS(std::tuple<double> args)
		{
			blockedByRShapeTS = controller.tryEmitRShapeTS(this, args);
		}
		
		bool canReceiveRShapeTS(std::tuple<double> args)
		{
			if(blockedByRShapeTS != nullptr)
				if(blockedByRShapeTS->getSender() == this)
					return false;
					
			blockedByRShapeTS = nullptr;
			
			switch(currentState)
			{
				case s_FINDING_FIRST_SHAPE:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_Y:
				{
					return true;
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_UNLOAD_ON_SECOND_SHAPE:
				{
					
					
					
					return false;
				}
				case s_GO_TO_HOME_POSITION:
				{
					
					
					
					return false;
				}
				default:
				{
					return false;
				}
			}
		}
		
		struct RShapeTS_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<double> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<double> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} rShapeTS_in;
		
		EventBuffer* blockedByLShapeX = nullptr;
		
		inline void tryEmitLShapeX(std::tuple<double> args)
		{
			blockedByLShapeX = controller.tryEmitLShapeX(this, args);
		}
		
		bool canReceiveLShapeX(std::tuple<double> args)
		{
			if(blockedByLShapeX != nullptr)
				if(blockedByLShapeX->getSender() == this)
					return false;
					
			blockedByLShapeX = nullptr;
			
			switch(currentState)
			{
				case s_FINDING_FIRST_SHAPE:
				{
					return true;
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_UNLOAD_ON_SECOND_SHAPE:
				{
					
					
					
					return false;
				}
				case s_GO_TO_HOME_POSITION:
				{
					
					
					
					return false;
				}
				default:
				{
					return false;
				}
			}
		}
		
		struct LShapeX_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<double> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<double> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} lShapeX_in;
		
		EventBuffer* blockedByLShapeY = nullptr;
		
		inline void tryEmitLShapeY(std::tuple<double> args)
		{
			blockedByLShapeY = controller.tryEmitLShapeY(this, args);
		}
		
		bool canReceiveLShapeY(std::tuple<double> args)
		{
			if(blockedByLShapeY != nullptr)
				if(blockedByLShapeY->getSender() == this)
					return false;
					
			blockedByLShapeY = nullptr;
			
			switch(currentState)
			{
				case s_FINDING_FIRST_SHAPE:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_X:
				{
					return true;
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_UNLOAD_ON_SECOND_SHAPE:
				{
					
					
					
					return false;
				}
				case s_GO_TO_HOME_POSITION:
				{
					
					
					
					return false;
				}
				default:
				{
					return false;
				}
			}
		}
		
		struct LShapeY_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<double> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<double> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} lShapeY_in;
		
		EventBuffer* blockedByLShapeTS = nullptr;
		
		inline void tryEmitLShapeTS(std::tuple<double> args)
		{
			blockedByLShapeTS = controller.tryEmitLShapeTS(this, args);
		}
		
		bool canReceiveLShapeTS(std::tuple<double> args)
		{
			if(blockedByLShapeTS != nullptr)
				if(blockedByLShapeTS->getSender() == this)
					return false;
					
			blockedByLShapeTS = nullptr;
			
			switch(currentState)
			{
				case s_FINDING_FIRST_SHAPE:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_Y:
				{
					return true;
					
					
					
					return false;
				}
				case s_FOUND_FIRST_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_X:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_Y:
				{
					
					
					
					return false;
				}
				case s_FOUND_SECOND_SHAPE_TS:
				{
					
					
					
					return false;
				}
				case s_UNLOAD_ON_SECOND_SHAPE:
				{
					
					
					
					return false;
				}
				case s_GO_TO_HOME_POSITION:
				{
					
					
					
					return false;
				}
				default:
				{
					return false;
				}
			}
		}
		
		struct LShapeTS_t : public EventBuffer
		{
			THREAD_SAFE_ONLY(std::mutex _mutex;)
			std::tuple<double> _args;
			void* _sender = nullptr;
			void* getSender() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				return _sender;
			}
			
			void reset() override
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_sender = nullptr;
			}
			
			void trigger(void* sender, std::tuple<double> args)
			{
				THREAD_SAFE_ONLY(std::lock_guard<std::mutex> lock{_mutex};)
				_args = args;
				_sender = sender;
			}
		} lShapeTS_in;
		
	
		enum PossibleStates
		{
			s_FINDING_FIRST_SHAPE,
			s_FOUND_FIRST_SHAPE_X,
			s_FOUND_FIRST_SHAPE_Y,
			s_FOUND_FIRST_SHAPE_TS,
			s_FOUND_SECOND_SHAPE_X,
			s_FOUND_SECOND_SHAPE_Y,
			s_FOUND_SECOND_SHAPE_TS,
			s_UNLOAD_ON_SECOND_SHAPE,
			s_GO_TO_HOME_POSITION,
			j_i0
		} currentState = j_i0; 

	
	// Constructor
	public:
		detectionBehaviourStm_StateMachine<Channels>(armPlatform& _robot, Channels& _controller) 
			: StateMachine<armPlatform, detectionBehaviourStm_StateMachine<Channels>>(_robot, *this), robot(_robot), controller(_controller)
			, 
			fINDING_FIRST_SHAPE_State{*this}, fOUND_FIRST_SHAPE_X_State{*this}, fOUND_FIRST_SHAPE_Y_State{*this}, fOUND_FIRST_SHAPE_TS_State{*this}, fOUND_SECOND_SHAPE_X_State{*this}, fOUND_SECOND_SHAPE_Y_State{*this}, fOUND_SECOND_SHAPE_TS_State{*this}, uNLOAD_ON_SECOND_SHAPE_State{*this}, gO_TO_HOME_POSITION_State{*this}
			{};
		~detectionBehaviourStm_StateMachine<Channels>() = default;
		detectionBehaviourStm_StateMachine<Channels>() = delete;
		
		bool blockedOnEvent()
		{
			if (blockedByLifted_TS != nullptr)
				if (blockedByLifted_TS->getSender() == this)
					return true;
			if (blockedByRShapeX != nullptr)
				if (blockedByRShapeX->getSender() == this)
					return true;
			if (blockedByRShapeY != nullptr)
				if (blockedByRShapeY->getSender() == this)
					return true;
			if (blockedByRShapeTS != nullptr)
				if (blockedByRShapeTS->getSender() == this)
					return true;
			if (blockedByLShapeX != nullptr)
				if (blockedByLShapeX->getSender() == this)
					return true;
			if (blockedByLShapeY != nullptr)
				if (blockedByLShapeY->getSender() == this)
					return true;
			if (blockedByLShapeTS != nullptr)
				if (blockedByLShapeTS->getSender() == this)
					return true;
			
			return false;
		}
		
		void execute() override
		{
			
			while(tryTransitions());
			if(blockedOnEvent()) return;
						
			switch(currentState)
			{
			case s_FINDING_FIRST_SHAPE:
				fINDING_FIRST_SHAPE_State.during();
				break;
			case s_FOUND_FIRST_SHAPE_X:
				fOUND_FIRST_SHAPE_X_State.during();
				break;
			case s_FOUND_FIRST_SHAPE_Y:
				fOUND_FIRST_SHAPE_Y_State.during();
				break;
			case s_FOUND_FIRST_SHAPE_TS:
				fOUND_FIRST_SHAPE_TS_State.during();
				break;
			case s_FOUND_SECOND_SHAPE_X:
				fOUND_SECOND_SHAPE_X_State.during();
				break;
			case s_FOUND_SECOND_SHAPE_Y:
				fOUND_SECOND_SHAPE_Y_State.during();
				break;
			case s_FOUND_SECOND_SHAPE_TS:
				fOUND_SECOND_SHAPE_TS_State.during();
				break;
			case s_UNLOAD_ON_SECOND_SHAPE:
				uNLOAD_ON_SECOND_SHAPE_State.during();
				break;
			case s_GO_TO_HOME_POSITION:
				gO_TO_HOME_POSITION_State.during();
				break;
			default:
				break;
			}
		}
		
		bool tryTransitions() override
		{
			if(blockedOnEvent())
				return false;
			
			switch(currentState)
			{
				case s_FINDING_FIRST_SHAPE:
				{
					if(lShapeX_in.getSender() != nullptr)
					{
						fINDING_FIRST_SHAPE_State.exit();
						lShapeX_in.reset();
						fOUND_FIRST_SHAPE_X_State.enter();
						currentState = s_FOUND_FIRST_SHAPE_X;
						return true;
					}
					
					
					break;
				}
				case s_FOUND_FIRST_SHAPE_X:
				{
					if(lShapeY_in.getSender() != nullptr)
					{
						fOUND_FIRST_SHAPE_X_State.exit();
						lShapeY_in.reset();
						fOUND_FIRST_SHAPE_Y_State.enter();
						currentState = s_FOUND_FIRST_SHAPE_Y;
						return true;
					}
					
					
					break;
				}
				case s_FOUND_FIRST_SHAPE_Y:
				{
					if(lShapeTS_in.getSender() != nullptr)
					{
						fOUND_FIRST_SHAPE_Y_State.exit();
						lShapeTS_in.reset();
						fOUND_FIRST_SHAPE_TS_State.enter();
						currentState = s_FOUND_FIRST_SHAPE_TS;
						return true;
					}
					
					
					break;
				}
				case s_FOUND_FIRST_SHAPE_TS:
				{
					if((eT.get()) <= (DELAY_DISCARD))
					if(rShapeX_in.getSender() != nullptr)
					{
						fOUND_FIRST_SHAPE_TS_State.exit();
						rShapeX_in.reset();
						fOUND_SECOND_SHAPE_X_State.enter();
						currentState = s_FOUND_SECOND_SHAPE_X;
						return true;
					}
					
					
					break;
				}
				case s_FOUND_SECOND_SHAPE_X:
				{
					if(rShapeY_in.getSender() != nullptr)
					{
						fOUND_SECOND_SHAPE_X_State.exit();
						rShapeY_in.reset();
						fOUND_SECOND_SHAPE_Y_State.enter();
						currentState = s_FOUND_SECOND_SHAPE_Y;
						return true;
					}
					
					
					break;
				}
				case s_FOUND_SECOND_SHAPE_Y:
				{
					if(rShapeTS_in.getSender() != nullptr)
					{
						fOUND_SECOND_SHAPE_Y_State.exit();
						rShapeTS_in.reset();
						fOUND_SECOND_SHAPE_TS_State.enter();
						currentState = s_FOUND_SECOND_SHAPE_TS;
						return true;
					}
					
					
					break;
				}
				case s_FOUND_SECOND_SHAPE_TS:
				{
					if(lifted_TS_in.getSender() != nullptr)
					{
						fOUND_SECOND_SHAPE_TS_State.exit();
						lifted_TS_in.reset();
						uNLOAD_ON_SECOND_SHAPE_State.enter();
						currentState = s_UNLOAD_ON_SECOND_SHAPE;
						return true;
					}
					
					
					break;
				}
				case s_UNLOAD_ON_SECOND_SHAPE:
				{
					if(lifted_TS_in.getSender() != nullptr)
					{
						uNLOAD_ON_SECOND_SHAPE_State.exit();
						lifted_TS_in.reset();
						gO_TO_HOME_POSITION_State.enter();
						currentState = s_GO_TO_HOME_POSITION;
						return true;
					}
					
					
					break;
				}
				case s_GO_TO_HOME_POSITION:
				{
					{
						gO_TO_HOME_POSITION_State.exit();
						fINDING_FIRST_SHAPE_State.enter();
						currentState = s_FINDING_FIRST_SHAPE;
						return true;
					}
					
					
					break;
				}
				case j_i0:
				{
					currentState = s_FINDING_FIRST_SHAPE;
					fINDING_FIRST_SHAPE_State.enter();
					return true;
				}
				default:
					break;
			}
			
			return false;
		}
};

#endif
