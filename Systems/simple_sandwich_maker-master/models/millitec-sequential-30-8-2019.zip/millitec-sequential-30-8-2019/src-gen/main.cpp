#include <iostream>
#include <unistd.h>
#include "RobotImpl.h"
#include "armController.h"

RobotImpl robot;

static constexpr long cycleDuration = 100e3;
			
int main(int argc, char** argv)
{
	ArmController armController{robot};
	
	while(true)
	{
		robot.Sense();
		
		// Signals to robot platform
		
		// Signals from robot platform
		if(robot.shouldTriggerLifted_TS())
			armController.channels.tryEmitLifted_TS(&robot, robot.getLifted_TSArgs());
			
		if(robot.shouldTriggerRShapeX())
			armController.channels.tryEmitRShapeX(&robot, robot.getRShapeXArgs());
			
		if(robot.shouldTriggerRShapeY())
			armController.channels.tryEmitRShapeY(&robot, robot.getRShapeYArgs());
			
		if(robot.shouldTriggerRShapeTS())
			armController.channels.tryEmitRShapeTS(&robot, robot.getRShapeTSArgs());
			
		if(robot.shouldTriggerLShapeX())
			armController.channels.tryEmitLShapeX(&robot, robot.getLShapeXArgs());
			
		if(robot.shouldTriggerLShapeY())
			armController.channels.tryEmitLShapeY(&robot, robot.getLShapeYArgs());
			
		if(robot.shouldTriggerLShapeTS())
			armController.channels.tryEmitLShapeTS(&robot, robot.getLShapeTSArgs());
			
		// Signals between controllers
				
		armController.Execute();
		
		robot.Actuate();
		
		#ifdef ROBOCALC_INTERACTIVE
		
		std::cout<<"Looped. Press enter for next iteration or q to quit."<<std::endl;
		char c;
		bool processingInput = true;
		while(processingInput)
		{
			std::cin.get(c);
			switch(c)
			{
				case '\n':
				{
					processingInput = false;
					break;
				}
				case 'q':
				case 'Q':
				{
					std::cout<<"Exiting"<<std::endl;
					return 0;
					break;
				}
				default:
					break;
			}
		}
		
		#else
			usleep(cycleDuration);				
		#endif
	}
	
	return 0;
}
