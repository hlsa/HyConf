#ifndef __ROBOT_IMPL_H__
#define __ROBOT_IMPL_H__

#include "armPlatform.h"

#include <set>
#include <algorithm>
#include <iostream>

class RobotImpl : public armPlatform
{
public:
		
	bool shouldTriggerLShapeY() override
	{
		std::cout<<"Should trigger event 'LShapeY'? (y/n)";
		char trigger;
		
		do { std::cin >> trigger; } while((trigger != 'y') && (trigger != 'n'));
		
		return trigger == 'y';
	}
	
	std::tuple<double> getLShapeYArgs() override
	{
		double ret;
		std::cout<<"Enter value for argument (double):";
		std::cin>>ret;
		return ret;
	};
		
	bool shouldTriggerRShapeY() override
	{
		std::cout<<"Should trigger event 'RShapeY'? (y/n)";
		char trigger;
		
		do { std::cin >> trigger; } while((trigger != 'y') && (trigger != 'n'));
		
		return trigger == 'y';
	}
	
	std::tuple<double> getRShapeYArgs() override
	{
		double ret;
		std::cout<<"Enter value for argument (double):";
		std::cin>>ret;
		return ret;
	};
		
	bool shouldTriggerLShapeX() override
	{
		std::cout<<"Should trigger event 'LShapeX'? (y/n)";
		char trigger;
		
		do { std::cin >> trigger; } while((trigger != 'y') && (trigger != 'n'));
		
		return trigger == 'y';
	}
	
	std::tuple<double> getLShapeXArgs() override
	{
		double ret;
		std::cout<<"Enter value for argument (double):";
		std::cin>>ret;
		return ret;
	};
		
	bool shouldTriggerRShapeTS() override
	{
		std::cout<<"Should trigger event 'RShapeTS'? (y/n)";
		char trigger;
		
		do { std::cin >> trigger; } while((trigger != 'y') && (trigger != 'n'));
		
		return trigger == 'y';
	}
	
	std::tuple<double> getRShapeTSArgs() override
	{
		double ret;
		std::cout<<"Enter value for argument (double):";
		std::cin>>ret;
		return ret;
	};
		
	bool shouldTriggerLifted_TS() override
	{
		std::cout<<"Should trigger event 'Lifted_TS'? (y/n)";
		char trigger;
		
		do { std::cin >> trigger; } while((trigger != 'y') && (trigger != 'n'));
		
		return trigger == 'y';
	}
	
	std::tuple<double> getLifted_TSArgs() override
	{
		double ret;
		std::cout<<"Enter value for argument (double):";
		std::cin>>ret;
		return ret;
	};
		
	bool shouldTriggerRShapeX() override
	{
		std::cout<<"Should trigger event 'RShapeX'? (y/n)";
		char trigger;
		
		do { std::cin >> trigger; } while((trigger != 'y') && (trigger != 'n'));
		
		return trigger == 'y';
	}
	
	std::tuple<double> getRShapeXArgs() override
	{
		double ret;
		std::cout<<"Enter value for argument (double):";
		std::cin>>ret;
		return ret;
	};
		
	bool shouldTriggerLShapeTS() override
	{
		std::cout<<"Should trigger event 'LShapeTS'? (y/n)";
		char trigger;
		
		do { std::cin >> trigger; } while((trigger != 'y') && (trigger != 'n'));
		
		return trigger == 'y';
	}
	
	std::tuple<double> getLShapeTSArgs() override
	{
		double ret;
		std::cout<<"Enter value for argument (double):";
		std::cin>>ret;
		return ret;
	};
	
	void pick() override
	{
		std::cout<<"Operation pick invoked on robot platform"<<std::endl;
	}
	void drop() override
	{
		std::cout<<"Operation drop invoked on robot platform"<<std::endl;
	}
	void lift() override
	{
		std::cout<<"Operation lift invoked on robot platform"<<std::endl;
	}
	void lower(double dist) override
	{
		std::cout<<"Operation lower invoked on robot platform"<<std::endl;
	}
	void set_v_theta(double v_t) override
	{
		std::cout<<"Operation set_v_theta invoked on robot platform"<<std::endl;
	}
	void set_v_radius(double v_r) override
	{
		std::cout<<"Operation set_v_radius invoked on robot platform"<<std::endl;
	}
};

#endif
