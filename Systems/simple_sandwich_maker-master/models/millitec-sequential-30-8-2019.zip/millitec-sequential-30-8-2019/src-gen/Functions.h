
#ifndef ROBOCALC_FUNCTIONS_H_
#define ROBOCALC_FUNCTIONS_H_

#include "DataTypes.h"
#include <vector>
#include <set>

namespace robocalc
{
	namespace functions
	{
		double get_t_x(double x);
		double calc_p_e_radius(double t_radius, double c_radius);
		double calc_i_radius(double e_radius, double p_e_radius, double step_size);
		double calc_radius(double t_x, double t_y);
		double calc_d_radius(double e_radius, double p_e_radius, double step_size);
		double calc_e_theta(double t_theta, double c_theta);
		double calc_i_theta(double e_theta, double p_e_theta, double step_size);
		double calc_v_theta(double e_theta, double i_theta, double d_theta);
		double calc_theta(double t_x, double t_y);
		double calc_e_radius(double t_radius, double c_radius);
		double calc_p_e_theta(double t_theta, double c_theta);
		double calc_d_theta(double e_theta, double p_e_theta, double step_size);
		double calc_v_radius(double e_radius, double i_radius, double d_radius);
		double update_t_y(double t_y, double speed, double step_size);
		double get_t_y(double y);
		
		template<typename T>
		std::set<T> set_union(std::set<T> s1, std::set<T> s2)
		{
			std::set<T> ret;
			ret.insert(s1.begin(), s1.end());
			ret.insert(s2.begin(), s2.end());
			return ret;
		}
		
		template<typename T>
		unsigned int size(std::set<T> s)
		{
			return s.size();
		}
	}
}

#endif
