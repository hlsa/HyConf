

stm simDetectionBehaviourStm{
	//const cycle : boolean
	cycleDef cycle ==1
	clock C 
	
	const HOME_X : nat
	const HOME_Y : nat
	const DELAY_DISCARD : real
	const WAIT_PICK : int
	const WAIT_DROP : int
	
	var shape1_x : real
	var shape1_y : real
	var shape1_ts : real
	var shape2_x : real
	var shape2_y : real
	var shape2_ts : real
	var liftTS : real
	
	//added
	requires platformConstI

	input context {
	    uses rCameraI 
		uses lCameraI
		uses feedbackI
	}
			
	output context {
		requires platformOpI 
		requires OpsCtrl
	}
	 
	initial i0
	state FINDING_FIRST_SHAPE { }
    state FOUND_FIRST_SHAPE_X { }  
    state FOUND_FIRST_SHAPE_Y { } 
    state FOUND_FIRST_SHAPE_TS { } 
    state FOUND_SECOND_SHAPE_X { }  
    state FOUND_SECOND_SHAPE_Y { } 
    state S_FOUND_SECOND_SHAPE_TS { 
    	//entry simArmController::interceptOp(shape1_x, shape1_y); $lower(HEIGHT_TO_SHAPE1) //added $
    	entry interceptOp(shape1_x, (shape1_y+(shape2_ts-shape1_ts)*BELT_SPEED)); $lower( HEIGHT_TO_SHAPE1 ) //added $
    }  
    state D_FOUND_SECOND_SHAPE_TS { }
    state S_PICK_FIRST_SHAPE {
    	entry $pick()
	}
    state D_PICK_FIRST_SHAPE { }
    state S_LIFT_FIRST_SHAPE { 
    	entry $lift()
    }
    state D_LIFT_FIRST_SHAPE { } 
    state S_UNLOAD_ON_SECOND_SHAPE {
    	entry  interceptOp ( shape2_x , (shape2_y+(liftTS-shape2_ts)*BELT_SPEED )); //added $ 
    	$lower( HEIGHT_TO_SHAPE2 )
    } 
    state D_UNLOAD_ON_SECOND_SHAPE { } 
    state S_DROP_ON_SECOND_SHAPE { 
    	entry $drop()
    }
    state D_DROP_ON_SECOND_SHAPE { }
    state S_LIFT_ON_SECOND_SHAPE {
    	entry $lift()
    }
    state D_LIFT_ON_SECOND_SHAPE { }
    state GO_TO_HOME_POSITION { 
    	entry pidOp( HOME_X , HOME_Y ) //added $
    } 
          
        transition t0{ 
        	from i0 to FINDING_FIRST_SHAPE
        }
        transition t1{
        	from FINDING_FIRST_SHAPE to FOUND_FIRST_SHAPE_X
        	condition $lShapeX?shape1_x
        }
        transition t2{
        	from FINDING_FIRST_SHAPE to FINDING_FIRST_SHAPE
        	exec condition not $lShapeX?shape1_x
        }
        transition t3{
        	from FOUND_FIRST_SHAPE_X to FOUND_FIRST_SHAPE_Y
        	condition $lShapeY?shape1_y
        }
        transition t4{
        	from FOUND_FIRST_SHAPE_Y to FOUND_FIRST_SHAPE_TS
        	condition $lShapeTS?shape1_ts
        }
        transition t5{
        	from FOUND_FIRST_SHAPE_TS to FOUND_SECOND_SHAPE_X
        	condition sinceEntry(FINDING_FIRST_SHAPE) <= DELAY_DISCARD /\ $rShapeX?shape2_x}
        transition t6{
        	from FOUND_FIRST_SHAPE_TS to FOUND_FIRST_SHAPE_TS
        	exec condition not $rShapeX?shape2_x /\ sinceEntry(FINDING_FIRST_SHAPE)<= DELAY_DISCARD
        }
        transition t7{
        	from FOUND_FIRST_SHAPE_TS to FINDING_FIRST_SHAPE
        	exec condition sinceEntry(FINDING_FIRST_SHAPE)> DELAY_DISCARD
        }
        transition t8{
        	from FOUND_SECOND_SHAPE_X to FOUND_SECOND_SHAPE_Y
        	condition $rShapeY?shape2_y
        }
        transition t9{
        	from FOUND_SECOND_SHAPE_Y to S_FOUND_SECOND_SHAPE_TS
        	condition $rShapeTS?shape2_ts
        }
        transition t11{
        	from S_FOUND_SECOND_SHAPE_TS to D_FOUND_SECOND_SHAPE_TS
        }
        transition t12{
        	from D_FOUND_SECOND_SHAPE_TS to D_FOUND_SECOND_SHAPE_TS
        	exec condition sinceEntry(S_FOUND_SECOND_SHAPE_TS)<=WAIT_LOWER_1
        }
        transition t13{
        	from D_FOUND_SECOND_SHAPE_TS to S_PICK_FIRST_SHAPE
        	condition sinceEntry(S_FOUND_SECOND_SHAPE_TS)> WAIT_LOWER_1
        }
        transition t14{
        	from S_PICK_FIRST_SHAPE to D_PICK_FIRST_SHAPE
        }
        transition t15{
        	from D_PICK_FIRST_SHAPE to D_PICK_FIRST_SHAPE
        	exec condition sinceEntry(S_PICK_FIRST_SHAPE)<= WAIT_PICK
        }
        transition t16{
        	from D_PICK_FIRST_SHAPE to S_LIFT_FIRST_SHAPE
        	condition sinceEntry(S_PICK_FIRST_SHAPE)> WAIT_PICK
        }
        transition t17{
        	from S_LIFT_FIRST_SHAPE to D_LIFT_FIRST_SHAPE
        }
        transition t18{
        	from D_LIFT_FIRST_SHAPE to D_LIFT_FIRST_SHAPE
        	exec condition not $lifted_TS?liftTS
        }
        transition t19{
        	from D_LIFT_FIRST_SHAPE to S_UNLOAD_ON_SECOND_SHAPE
        	condition $lifted_TS?liftTS
        }
        transition t20{
        	from S_UNLOAD_ON_SECOND_SHAPE to D_UNLOAD_ON_SECOND_SHAPE
        }
        transition t21{
        	from D_UNLOAD_ON_SECOND_SHAPE to D_UNLOAD_ON_SECOND_SHAPE
        	exec condition sinceEntry(S_UNLOAD_ON_SECOND_SHAPE)<= HEIGHT_TO_SHAPE2
        }
        transition t23{
        	from D_UNLOAD_ON_SECOND_SHAPE to S_DROP_ON_SECOND_SHAPE
        	condition sinceEntry(S_UNLOAD_ON_SECOND_SHAPE)> HEIGHT_TO_SHAPE2
        }
        transition t24{
        	from S_DROP_ON_SECOND_SHAPE to D_DROP_ON_SECOND_SHAPE
        }
        transition t25{
        	from D_DROP_ON_SECOND_SHAPE to D_DROP_ON_SECOND_SHAPE
        	exec condition sinceEntry(S_DROP_ON_SECOND_SHAPE)<= WAIT_DROP
        }
        transition t26{
        	from D_DROP_ON_SECOND_SHAPE to S_LIFT_ON_SECOND_SHAPE
        	condition sinceEntry(S_DROP_ON_SECOND_SHAPE)> WAIT_DROP
        }
        transition t27{
        	from S_LIFT_ON_SECOND_SHAPE to D_LIFT_ON_SECOND_SHAPE
        }
        transition t28{
        	from D_LIFT_ON_SECOND_SHAPE to D_LIFT_ON_SECOND_SHAPE
        	exec condition not $lifted_TS?liftTS
        }
        transition t29{
        	from D_LIFT_ON_SECOND_SHAPE to GO_TO_HOME_POSITION
        	condition $lifted_TS?liftTS
        }
        transition t30{
        	from GO_TO_HOME_POSITION to FINDING_FIRST_SHAPE
        }
}
    		