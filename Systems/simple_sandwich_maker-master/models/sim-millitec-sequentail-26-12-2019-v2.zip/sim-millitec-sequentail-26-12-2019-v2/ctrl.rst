import calc_estimate::*

interface OpsCtrl{
	interceptOp(x: real, y: real)
	pidOp(x: real, y: real)
}

controller simArmController {
//	const cycle : boolean
	cycleDef cycle ==1
	
	requires platformOpI
	requires platformConstI
	uses rCameraI 
	uses lCameraI
	uses feedbackI

	
	sref stm_ref0 = simDetectionBehaviourStm 
	
    connection simArmController on lShapeX to stm_ref0 on lShapeX 
    connection simArmController on lShapeY to stm_ref0 on lShapeY 
    connection simArmController on lShapeTS to stm_ref0 on lShapeTS
    connection simArmController on rShapeX to stm_ref0 on rShapeX 
    connection simArmController on rShapeY to stm_ref0 on rShapeY 
    connection simArmController on rShapeTS to stm_ref0 on rShapeTS
    connection simArmController on lifted_TS to stm_ref0 on lifted_TS



	operation interceptOp(x: real, y: real) {
		
		requires platformOpI //added
		requires platformConstI
		
		const epsilon_theta: real
		const epsilon_radius: real
		var t_x: real
		var t_y: real
		var c_theta: real
		var c_radius: real
		var i_theta : real
		var i_radius : real
		var p_e_theta: real
		var p_e_radius: real
		var e_theta: real
		var e_radius: real
		var d_theta: real
		var d_radius: real
		var t_theta: real
		var t_radius: real
		var v_theta: real
		var v_radius: real
			
		
	    initial i0
		junction j0
		final f0 
	                             
		state STEP{ entry e_theta = calc_e_theta ( t_theta , c_theta ) ; e_radius = calc_e_radius ( t_radius , c_radius ) ; d_theta = calc_d_theta ( e_theta , p_e_theta , STEP_SIZE ) ; d_radius = calc_d_radius ( e_radius , p_e_radius , STEP_SIZE ) ; i_theta = i_theta + calc_i_theta ( e_theta , p_e_theta , STEP_SIZE ) ; i_radius = i_radius + calc_i_radius ( e_radius , p_e_radius , STEP_SIZE ) ; v_theta = calc_v_theta ( e_theta , i_theta , d_theta ) ;
		                  $set_v_theta( v_theta ); v_radius = calc_v_radius ( e_radius , i_radius , d_radius ) ;
                          $set_v_radius( v_radius )
	    }     	   
		transition t0 {
			from i0
			to STEP
			action t_x = get_t_x ( x ) ; t_y = get_t_y ( y ) ; p_e_theta = 0.0 ; p_e_radius = 0.0 ; d_theta = 0.0 ; d_radius = 0.0 ; i_theta = 0.0 ; i_radius = 0.0 ; t_theta = calc_theta ( t_x , t_y ) ; t_radius = calc_radius ( t_x , t_y ) ; p_e_theta = calc_p_e_theta ( t_theta , c_theta ) ; p_e_radius = calc_p_e_radius ( t_radius , c_radius )
		}
		transition t2 {
			from STEP
			to j0
		}
		transition t3 {
			from j0
			to f0
			condition ( e_theta < epsilon_theta /\ - epsilon_theta < e_theta /\ e_radius < epsilon_radius /\ - epsilon_radius < e_theta )
			action v_theta = 0.0 ; v_radius = 0.0 
		}
		transition t4 {
			from j0
			to STEP
			exec condition not ( e_theta < epsilon_theta /\ - epsilon_theta < e_theta /\ e_radius < epsilon_radius /\ - epsilon_radius < e_theta )
			action p_e_theta = e_theta ; p_e_radius = e_radius ; t_y = update_t_y ( t_y , BELT_SPEED , STEP_SIZE ) ; t_radius = calc_radius ( t_x , t_y ) ; t_theta = calc_theta ( t_x , t_y )
		}
	    
	}



	operation pidOp(x: real, y: real) {
		
		requires platformOpI 
		requires platformConstI
		
		const epsilon_theta: real 
		const epsilon_radius: real
		var t_x: real
		var t_y: real
		var c_theta: real
		var c_radius: real
		var i_theta : real
		var i_radius : real
		var p_e_theta: real
		var p_e_radius: real
		var e_theta: real
		var e_radius: real
		var d_theta: real
		var d_radius: real
		var t_theta: real
		var t_radius: real
		var v_theta: real
		var v_radius: real
		
		initial i0
		junction j0
		final f0 
	                             
		state STEP{ entry e_theta = calc_e_theta ( t_theta , c_theta ) ; e_radius = calc_e_radius ( t_radius , c_radius ) ; d_theta = calc_d_theta ( e_theta , p_e_theta , STEP_SIZE ) ; d_radius = calc_d_radius ( e_radius , p_e_radius , STEP_SIZE ) ; i_theta = i_theta + calc_i_theta ( e_theta , p_e_theta , STEP_SIZE ) ; i_radius = i_radius + calc_i_radius ( e_radius , p_e_radius , STEP_SIZE ) ; v_theta = calc_v_theta ( e_theta , i_theta , d_theta ) ;
		                  $set_v_theta( v_theta ); v_radius = calc_v_radius ( e_radius , i_radius , d_radius ) ;
                          $set_v_radius( v_radius )
	    }     	   
		transition t0 {
			from i0
			to STEP
			action t_x = get_t_x ( x ) ; t_y = get_t_y ( y ) ; p_e_theta = 0.0 ; p_e_radius = 0.0 ; d_theta = 0.0 ; d_radius = 0.0 ; i_theta = 0.0 ; i_radius = 0.0 ; t_theta = calc_theta ( t_x , t_y ) ; t_radius = calc_radius ( t_x , t_y ) ; p_e_theta = calc_p_e_theta ( t_theta , c_theta ) ; p_e_radius = calc_p_e_radius ( t_radius , c_radius )
		}
		transition t2 {
			from STEP
			to j0
		}
		transition t3 {
			from j0
			to f0
			condition ( e_theta < epsilon_theta /\ - epsilon_theta < e_theta /\ e_radius < epsilon_radius /\ - epsilon_radius < e_theta )
			action v_theta = 0.0 ; v_radius = 0.0 
		}
		transition t4 {
			from j0
			to STEP
			exec condition not ( e_theta < epsilon_theta /\ - epsilon_theta < e_theta /\ e_radius < epsilon_radius /\ - epsilon_radius < e_theta )
			action p_e_theta = e_theta ; p_e_radius = e_radius
		}
	}

}

