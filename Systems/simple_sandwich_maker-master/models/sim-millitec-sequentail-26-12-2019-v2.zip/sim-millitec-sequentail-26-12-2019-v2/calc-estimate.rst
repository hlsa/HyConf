package
calc_estimate

//function calc_theta(t_x: real, t_y: real) : real { postcondition acos(t_x/ sqrt(t_x * t_x + t_y * t_y))}

function calc_theta(t_x: real, t_y: real) : real {}

// function calc_radius(t_x: real, t_y: real) : real {postcondition sqrt(t_x * t_x + t_y * t_y) - 0.32}
	
function calc_radius(t_x: real, t_y: real) : real {}

function get_t_x(x: real) : real {postcondition x + 0.47}

function get_t_y(y : real) : real { postcondition y}

function calc_p_e_theta(t_theta: real, c_theta:real) : real {postcondition t_theta - c_theta}

function calc_p_e_radius(t_radius: real, c_radius:real) : real {postcondition t_radius - c_radius}

function calc_e_theta(t_theta: real, c_theta: real): real {postcondition t_theta - c_theta}

function calc_e_radius(t_radius: real, c_radius:real) : real{postcondition t_radius - c_radius}

function calc_d_theta(e_theta: real, p_e_theta: real, step_size: real) : real {postcondition (e_theta - p_e_theta) / step_size}

function calc_d_radius(e_radius: real, p_e_radius: real, step_size: real) : real{postcondition (e_radius - p_e_radius) / step_size}

function calc_i_theta(e_theta:real , p_e_theta:real, step_size: real) : real {postcondition (e_theta - p_e_theta) * step_size}

function calc_i_radius(e_radius: real, p_e_radius: real, step_size: real) : real{postcondition (e_radius - p_e_radius) * step_size}

function calc_v_theta(e_theta: real, i_theta: real, d_theta:real) : real { postcondition 6.2*e_theta+0.2*i_theta+0.4*d_theta }

function calc_v_radius(e_radius: real, i_radius: real, d_radius: real) : real{ postcondition 5.2*e_radius+0.2*i_radius+0.4*d_radius}

function update_t_y (t_y: real , speed: real , step_size: real) : real {postcondition t_y + speed*step_size}