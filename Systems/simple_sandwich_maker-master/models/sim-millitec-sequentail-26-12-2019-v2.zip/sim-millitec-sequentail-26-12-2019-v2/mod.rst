interface platformOpI {
	pick() 
	drop() 
	lift() 
	lower( dist : real) 
	set_v_theta(v_t: real)
	set_v_radius(v_r: real)
}

interface platformConstI{
	const HEIGHT_TO_SHAPE1: real
	const HEIGHT_TO_SHAPE2: real
	const WAIT_LOWER_1 : nat
	const WAIT_LOWER_2 : nat
	const BELT_SPEED : real
	const STEP_SIZE: real 	
}

interface rCameraI {
	event rShapeX : real
	event rShapeY : real
	event rShapeTS : real
}

interface lCameraI {
	event lShapeX : real
	event lShapeY : real
	event lShapeTS : real
}


interface feedbackI {
	event lifted_TS : real
}

operation pick() {}

operation drop() {}

operation lower( dist : real) {}

operation lift( ) {}

operation set_v_theta(v_t: real) {}

operation set_v_radius(v_r: real) {} 
  
 module simPickerModule {
	//const cycle : boolean
	cycleDef cycle ==1
	
	robotic platform simArmPlatform {
    uses rCameraI
    uses lCameraI 
    provides platformOpI 
    provides platformConstI
    uses feedbackI
	}
		
	cref ctrl_ref0 = simArmController
	
    connection simArmPlatform on lShapeX to ctrl_ref0 on lShapeX ( _async ) 
    connection simArmPlatform on lShapeY to ctrl_ref0 on lShapeY ( _async ) 
    connection simArmPlatform on lShapeTS to ctrl_ref0 on lShapeTS ( _async ) 
    connection simArmPlatform on rShapeX to ctrl_ref0 on rShapeX ( _async ) 
    connection simArmPlatform on rShapeY to ctrl_ref0 on rShapeY ( _async ) 
    connection simArmPlatform on rShapeTS to ctrl_ref0 on rShapeTS ( _async ) 
    connection simArmPlatform on lifted_TS to ctrl_ref0 on lifted_TS ( _async )
}
 

 