interface TurnConstants {
	const TURN_EFFORT: real = -1
	const KP: real = 0.9
	const KI: real = 0.0
	const KD: real = 0.0
	const MAX_SPEED: real = 2.0
	const ANGLE_ZERO: real = 0.01
}

operation turn (angle: real) {
	requires AngularVariables
	var angleE: real = 0.0, anglePE: real = 0.0
	var angleI: real = 0.0
	var angleO: real, normalisedO: real
	uses ControllerConstants
	uses TurnConstants
	initial i
	state GetError {
		entry angleE = sign ( angle ) * ( abs ( angle ) - abs ( theta ) )
	}
	state CalculateOutput {
		entry angleI = angleI + angleE * STEP_SIZE * NCYCLES ; angleO = KP * angleE + KI * angleI + KD * ( ( anglePE - angleE ) / ( STEP_SIZE * NCYCLES ) ) ; anglePE = angleE
	}
	state Normalise {
		entry normalisedO = if ( angleO > MAX_SPEED ) then MAX_SPEED else if ( angleO < MAX_SPEED ) then - MAX_SPEED else angleO end end
	}
	state SetSpeed {
		entry output_left_motor( normalisedO ); output_right_motor(- normalisedO )
	}
	final f0
	transition t0 {
		from i
		to GetError
		action set_left_effort_limit( TURN_EFFORT ); set_right_effort_limit( TURN_EFFORT ) 
	}
	transition t1 {
		from GetError
		to CalculateOutput
		condition else	
	}
	transition t2 {
		from GetError
		to f0
		condition abs ( angleE ) <= ANGLE_ZERO
	}
	transition t3 {
		from CalculateOutput
		to Normalise
	}
	transition t4 {
		from Normalise
		to SetSpeed
	}
	transition t5 {
		from SetSpeed
		to GetError
		exec
	}
	input context {
		
	}
	output context {
		requires Actuators
	}
}

