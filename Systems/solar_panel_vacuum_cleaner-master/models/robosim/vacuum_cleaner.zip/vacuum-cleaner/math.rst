function sqrt(x: real): real {
	precondition x >= 0
	postcondition result*result == x // SHOULD THIS ACCOUNT FOR ERROR TOLERANCE? 
}

function sign(x:real): real {
	postcondition (x >= 0.0 /\ result == 1.0) \/ (x < 0.0 /\ result == -1.0)
}

function abs(x: real): real {
	postcondition (x >= 0.0 /\ result == x) \/ (x < 0.0 /\ result == -x)
}