stm Kinematics {
	cycleDef cycle == 5
	requires LinearVariables
	requires AngularVariables
	uses ControllerConstants
	uses Constants
	var acc_l: Acceleration, acc_r: Acceleration
	var spd_l: real, spd_r: real
	input context {
		uses KinematicInterface
	}
	output context {
		
	}
	initial i
	state ReadInputs {
		 
	}
	state Update {
		entry aSpeed = sqrt((abs(acc_r.Y - acc_l.Y))/(2*ACC_DIST));
			  lSpeed = WHL_RADIUS*(spd_l+spd_r)/2;
			  dist = dist + lSpeed * STEP_SIZE * NCYCLES;
			  theta = theta + aSpeed * STEP_SIZE * NCYCLES
	}
	transition t0 {
		from i to ReadInputs
	}
	transition t1 {
		from ReadInputs to Update
		condition $leftAccelerometer?acc_l /\ $rightAccelerometer?acc_r /\ $leftWheelSpeed?spd_l /\ $rightWheelSpeed?spd_r
		// Do I need to let time pass here if these values are not available? The assumption here is that the values are always available.
	}
	transition t2 {
		from Update to ReadInputs
		exec
	}
}

