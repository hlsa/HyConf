record Acceleration {
	X: real
	Y: real
	Z: real
}

interface Actuators {
	output_left_motor(speed: real)
	output_right_motor(speed: real)
	set_left_effort_limit(torque: real)
	set_right_effort_limit(torque: real)
}

interface KinematicInterface {
	event leftWheelSpeed: real
	event rightWheelSpeed: real
	event leftAccelerometer: Acceleration
	event rightAccelerometer: Acceleration
}

interface Operations {
	move()
	turn(angle: real) // in radians
	stop()
}

interface Sensors {
	event ultrasonic : real
	event battery : nat
}

interface Constants {
	const PI : real = 3.1415
	const BATTERY_LOW : real = 10.0
	const EDGE_HEIGHT : real = 0.3
	const ROBOT_LENGTH : real = 0.1
	const CHARGING_TIME : nat = 10000
	const ACC_DIST : real = 0.045
	const WHL_DIST : real = 0.04
	const BRIDGE_LENGTH : real = 0.2
	const WHL_RADIUS : real = 0.01
}

module VacuumCleanerModule {
	cycleDef cycle == 5

	robotic platform VacuumCleaner {
		uses Sensors
		uses KinematicInterface
		provides Actuators
	}

	cref ctrl = VacuumCleanerCtrl
	connection VacuumCleaner on ultrasonic to ctrl on ultrasonic ( _async )
	connection VacuumCleaner on rightWheelSpeed to ctrl on rightWheelSpeed ( _async )
	connection VacuumCleaner on leftWheelSpeed to ctrl on leftWheelSpeed ( _async )
	connection VacuumCleaner on battery to ctrl on battery ( _async )
	connection VacuumCleaner on leftAccelerometer to ctrl on leftAccelerometer ( _async )
	connection VacuumCleaner on rightAccelerometer to ctrl on rightAccelerometer ( _async )
}

