interface PlanningVariables {
	var done: boolean = false
	var u: real, b: real
	var cleaningDone: boolean = false, cleaningCycles : nat = 0
}

stm PathPlanning {
	cycleDef cycle == 5
	uses Constants 
	uses PlanningVariables
	requires LinearVariables
	requires AngularVariables
	requires Operations
	input context {
		uses Sensors	
	}
	output context {
	}
	initial i
	state LeaveCharger {
		initial i
		state Turn {
			entry turn( PI /2)
			exit exec; stop()
		}
		state MoveOut {
			during move()
			exit exec; stop()
		}
		junction Restart
		final f0
		state TurnN2E {
			entry turn( PI /2)
			exit exec; stop()
		}
		state MoveEastBottom {
			during move ( )
			exit stop ( )
		}

		transition t0 {
			from i
			to Turn
			action done = false
		}
		transition t1 {
			from Turn
			to MoveOut
		}
		transition t2 {
			from MoveOut
			to Restart
			condition dist >= ROBOT_LENGTH
		}
		transition t3 {
			from Restart
			to f0
			condition cleaningCycles == 0
			action done = true
		}
		transition t4 {
			from Restart
			to TurnN2E
			condition else
		}
		transition t5 {
			from TurnN2E
			to MoveEastBottom
		}
		transition t6 {
			from MoveEastBottom
			to f0
			condition dist >= cleaningCycles * ROBOT_LENGTH
			action done = true
		}
	}
	state Cycle {
		initial i0
		state MoveNorth {
			during move ( )

			exit exec ; stop ( )
		}
		state TurnN2E {
			entry turn( PI /2)
			exit stop ( )
		}
		state MoveEastTop {
			during move()
			exit exec; stop()
		}
		state TurnE2S {
			entry turn( PI /2)
			exit exec; stop()
		}
		state MoveSouth {
			during move()
			exit exec; stop()
		}
		state TurnS2E {
			entry turn(- PI /2)
			exit exec; stop()
		}
		state MoveEastBottom {
			during move()
			exit exec; stop()
		}
		final f0
		transition t0 {
			from i0
			to MoveNorth
			action done = false
		}
		transition t1 {
			from MoveNorth
			to TurnN2E
			condition $ultrasonic?u /\ u >= EDGE_HEIGHT
		}
		transition t2 {
			from TurnN2E
			to MoveEastTop
		}
		transition t3 {
			from MoveEastTop
			to TurnE2S
			condition dist >= ROBOT_LENGTH
		}
		transition t4 {
			from TurnE2S
			to MoveSouth
		}
		transition t5 {
			from MoveSouth
			to TurnS2E
			condition $ultrasonic?u /\ u >= EDGE_HEIGHT
		}
		transition t7 {
			from MoveEastBottom
			to f0
			condition not $ultrasonic /\ dist >= ROBOT_LENGTH
			action done = true
		}
		transition t6 {
			from TurnS2E
			to MoveEastBottom
		}
		transition t8 {
			from MoveEastBottom
			to f0
			condition $ultrasonic?u /\ u >= EDGE_HEIGHT
			action cleaningDone = true ; done = true
		}
	}
	state TurnE2N {
		entry turn(- PI /2)
		exit exec; stop()
	}
	junction j0
	state GoToCharger {
		initial i0
		state TurnE2W {
			entry turn( PI )
			exit exec; stop()
		}
		state MoveWest {
			during move()
			exit exec; stop()
		}
		state TurnW2S {
			entry turn(- PI /2)
			exit exec; stop()
		}
		state MoveSouth {
			during move()
			exit exec; stop()
		}
		state TurnS2W {
			entry turn(- PI /2)
			exit exec; stop()
		}
		state Charge {
			entry wait( CHARGING_TIME ); done = true
		}
		transition t0 {
			from i0
			to TurnE2W
			action done = false
		}
		transition t1 {
			from TurnE2W
			to MoveWest
		}
		transition t2 {
			from MoveWest
			to TurnW2S
			condition $ultrasonic?u /\ u >= EDGE_HEIGHT
		}
		transition t3 {
			from TurnW2S
			to MoveSouth
		}
		transition t4 {
			from MoveSouth
			to TurnS2W
			condition $ultrasonic?u /\ u >= EDGE_HEIGHT
		}
		transition t5 {
			from TurnS2W
			to Charge
		}
	}
	transition t0 {
		from i
		to LeaveCharger
		action cleaningCycles = 0 ; cleaningDone = false
	}
	transition t1 {
		from LeaveCharger
		to Cycle
		condition done
	}
	transition t2 {
		from Cycle
		to j0
		condition done
	}
	transition t3 {
		from TurnE2N
		to Cycle
	}
	transition t4 {
		from j0
		to TurnE2N
		condition else
		action cleaningCycles = cleaningCycles + 1
	}
	transition t5 {
		from j0
		to GoToCharger
		condition $battery?b /\ b <= BATTERY_LOW /\ not cleaningDone
	}
	transition t6 {
		from j0
		to GoToCharger
		condition cleaningDone
		action cleaningCycles = 0 ; cleaningDone = false
	}
	transition t7 {
		from GoToCharger
		to LeaveCharger
		condition done
	}
}

