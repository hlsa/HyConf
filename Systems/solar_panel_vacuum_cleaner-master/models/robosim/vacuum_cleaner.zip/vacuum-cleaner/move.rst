interface MoveConstants {
	const FORWARD_EFFORT: real = 1.2
	const FORWARD_SPEED: real = 2
}

operation move () {
	uses MoveConstants
	initial i
	state SetSpeed {
		entry set_left_effort_limit(FORWARD_EFFORT); set_right_effort_limit(FORWARD_EFFORT); output_left_motor(FORWARD_SPEED); output_right_motor(FORWARD_SPEED)
	}
	transition t0 {
		from i
		to SetSpeed
	}
	transition t1 {
		from SetSpeed
		to SetSpeed
		exec
	}
	input context {
		
	}
	output context {
		requires Actuators
	}
}

