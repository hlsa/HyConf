interface ControllerConstants {
	const STEP_SIZE : real = 0.001
	const NCYCLES: int = 5
}

interface LinearVariables {
	var dist: real, lSpeed: real
}

interface AngularVariables {
	var theta: real, aSpeed: real
}

// There is a problem with a WFC, which should take operations defined/referenced in the controller into account

controller VacuumCleanerCtrl {
	uses LinearVariables 
	uses AngularVariables

	cycleDef cycle == 5
	sref k = Kinematics
	sref p = PathPlanning
	uses Sensors uses KinematicInterface
	
	opref turn = turn
	opref move = move
	opref stop = stop
	connection VacuumCleanerCtrl on ultrasonic to p on ultrasonic
	connection VacuumCleanerCtrl on battery to p on battery
	connection VacuumCleanerCtrl on leftWheelSpeed to k on leftWheelSpeed
	connection VacuumCleanerCtrl on rightWheelSpeed to k on rightWheelSpeed
	connection VacuumCleanerCtrl on leftAccelerometer to k on leftAccelerometer
	connection VacuumCleanerCtrl on rightAccelerometer to k on rightAccelerometer
}

