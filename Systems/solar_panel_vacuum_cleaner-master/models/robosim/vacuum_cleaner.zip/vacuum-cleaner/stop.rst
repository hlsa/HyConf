interface StopConstants {
	const LIN_SPD_ZERO: real = 0.001
	const ANG_SPD_ZERO: real = 0.001 
}

operation stop () {
	uses StopConstants
	requires LinearVariables
	requires AngularVariables
	
	initial i
	state SetSpeed {
		entry output_left_motor(0); output_right_motor(0)
	}
	final f0
	transition t0 {
		from i
		to SetSpeed
	}
	transition t1 {
		from SetSpeed
		to SetSpeed
		exec
	}
	transition t2 {
		from SetSpeed
		to f0
		condition abs ( lSpeed ) <= LIN_SPD_ZERO /\ abs ( aSpeed ) <= ANG_SPD_ZERO
		action dist = 0 ; theta = 0 ; lSpeed = 0 ; aSpeed = 0
	}
	input context {
		uses Sensors
	}
	output context {
		requires Actuators
	}
}

