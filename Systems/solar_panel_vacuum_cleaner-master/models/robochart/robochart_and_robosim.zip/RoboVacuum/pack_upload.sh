refines --archive test.csp csp-gen/sim/aux_assertions_assertions.csp
scp test.csp ahm504@scp.york.ac.uk:~/
