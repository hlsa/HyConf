stm SimSpeedSM {
	cycleDef cycle == 1
	input context {
		event acc: TripleAxis
		event sp_ack
	}
	output context {
		event sp: TripleAxis
		event acc_ack
	}
	var speed: TripleAxis, acceleration: TripleAxis
	const t: int
	initial I
	state wait_input{}
	state update_speed {
		entry speed.X = speed.X + acceleration.X*t;
			  speed.Y = speed.Y + acceleration.Y*t;
			  speed.Z = speed.Z + acceleration.Z*t
	}
	state wait_sp_ack{}
	transition t0 {
		from I to wait_input
		action speed.X = 0; speed.Y = 0; speed.Z = 0
	}
	transition t1 {
		from wait_input
		to update_speed
		condition $acc?acceleration
		action $acc_ack
	}
	transition t1exec {
		from wait_input
		to wait_input
		exec
		condition not $acc?acceleration
	}
	transition t2 {
		from update_speed
		to wait_sp_ack
		action $sp!speed
	}
	transition t3 {
		from wait_sp_ack
		to wait_input
		condition $sp_ack
		action wait(t)
	}
	transition t3exec {
		from wait_sp_ack
		to wait_sp_ack
		exec
		condition not $sp_ack
	}
}
