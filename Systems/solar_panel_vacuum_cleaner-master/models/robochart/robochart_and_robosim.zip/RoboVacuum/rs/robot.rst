//interface SimData {
//	const C: nat = 1
//}

module SimModule {
	cycleDef cycle == 1

	controller SimPathPlanningController {
		cycleDef cycle == 1

		requires MovementOperations 
		uses SensorEvents requires CleaningOperations event acc_l : TripleAxis
		event acc_r : TripleAxis

		sref stm_ref0 = SimPathPlanningSM
		sref stm_ref1 = SimSpeedSM
		sref stm_ref2 = SimSpeedSM
		sref stm_ref3 = SimDisplacementSM
		sref stm_ref4 = SimCleanSM
		sref stm_ref5 = SimAngularSpeedSM
		sref stm_ref6 = SimPID
		sref stm_ref7 = SimPID
		sref stm_ref8 = SimMidLevelSM
		sref stm_ref9 = SimLinearSpeedSM
		sref stm_ref10 = SimInputDuplicationSM
		sref stm_ref11 = SimInputDuplicationSM
		sref stm_ref12 = SimInputDuplicationSM
		
		connection stm_ref0 on clean to stm_ref4 on clean

		connection SimPathPlanningController on ultrasonic to stm_ref0 on ultrasonic
		connection SimPathPlanningController on battery_level to stm_ref0 on battery_level
		connection SimPathPlanningController on charging to stm_ref0 on charging

		connection stm_ref8 on target_speed to stm_ref7 on target
		connection stm_ref7 on err_output to stm_ref8 on speed_adjustment
		connection stm_ref8 on target_angle to stm_ref6 on target
		connection stm_ref6 on err_output to stm_ref8 on angle_adjustment
		connection stm_ref5 on angle to stm_ref6 on actual
		connection stm_ref0 on move_forward to stm_ref8 on move_forward
		connection stm_ref0 on turn to stm_ref8 on turn
		
		connection stm_ref1 on sp to stm_ref9 on speed_l

		connection stm_ref9 on linear_speed to stm_ref7 on actual

		connection SimPathPlanningController on acc_l to stm_ref10 on i
		connection stm_ref10 on o1 to stm_ref1 on acc
		connection stm_ref10 on o2 to stm_ref5 on acc_l
		connection SimPathPlanningController on acc_r to stm_ref11 on i
		connection stm_ref11 on o1 to stm_ref2 on acc
		connection stm_ref11 on o2 to stm_ref5 on acc_r
		connection stm_ref2 on sp to stm_ref12 on i
		connection stm_ref12 on o1 to stm_ref3 on sp
		connection stm_ref12 on o2 to stm_ref9 on speed_r
		connection stm_ref0 on stop to stm_ref8 on stop
		connection stm_ref3 on displacement_out to stm_ref0 on displacement_in
		connection stm_ref0 on displacement_out to stm_ref3 on displacement_in
		connection stm_ref4 on clean_ack to stm_ref0 on clean_ack
		connection stm_ref3 on displacement_in_ack to stm_ref0 on displacement_out_ack
		connection stm_ref0 on displacement_in_ack to stm_ref3 on displacement_out_ack
		connection stm_ref3 on sp_ack to stm_ref12 on o_ack1
		connection stm_ref9 on speed_r_ack to stm_ref12 on o_ack2
		connection stm_ref7 on actual_ack to stm_ref9 on ls_ack
		connection stm_ref7 on target_ack to stm_ref8 on target_speed_ack
		connection stm_ref8 on speed_adjustment_ack to stm_ref7 on err_ack
		connection stm_ref1 on acc_ack to stm_ref10 on o_ack1
		connection stm_ref6 on target_ack to stm_ref8 on target_angle_ack
		connection stm_ref8 on angle_adjustment_ack to stm_ref6 on err_ack
		connection stm_ref9 on speed_l_ack to stm_ref1 on sp_ack
		connection stm_ref5 on acc_l_ack to stm_ref10 on o_ack2
		connection stm_ref6 on actual_ack to stm_ref5 on angle_ack
		connection stm_ref5 on acc_r_ack to stm_ref11 on o_ack2
		connection stm_ref2 on acc_ack to stm_ref11 on o_ack1
		connection stm_ref12 on i_ack to stm_ref2 on sp_ack
		connection stm_ref8 on turn_ack to stm_ref0 on turn_ack
		connection stm_ref8 on move_forward_ack to stm_ref0 on move_forward_ack
		connection stm_ref8 on stop_ack to stm_ref0 on stop_ack
	}

	robotic platform Platform {
		provides MovementOperations provides CleaningOperations
		uses SensorEvents
		event acc_l : TripleAxis
		event acc_r : TripleAxis
	}

	connection Platform on acc_l to SimPathPlanningController on acc_l ( _async )
	connection Platform on acc_r to SimPathPlanningController on acc_r ( _async )
	connection Platform on battery_level to SimPathPlanningController on battery_level ( _async )
	connection Platform on charging to SimPathPlanningController on charging (_async )
	connection Platform on ultrasonic to SimPathPlanningController on ultrasonic (_async )
}

