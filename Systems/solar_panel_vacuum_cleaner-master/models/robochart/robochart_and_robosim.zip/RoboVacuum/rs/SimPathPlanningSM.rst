interface CleaningEventsAck {
	event clean_ack
}

interface MovementCommandsAck {
	event move_forward_ack
	event turn_ack
	event stop_ack
}

interface SensorEventsAck {
	event ultrasonic_ack
	event battery_level_ack
	event charging_ack
}

stm SimPathPlanningSM {
	cycleDef cycle == 1
	uses SensorConstants
	
	var cycles : int
	input context {
		uses SensorEvents
		uses CleaningEventsAck
		uses MovementCommandsAck
		event displacement_in : int
		event displacement_out_ack
	}
	output context {
		uses MovementCommands
		uses CleaningEvents
		uses SensorEventsAck
		event displacement_out : int
		event displacement_in_ack
	}

	initial i0
	state ResumeEntry1 {
		entry $turn ! Direction::right
	}
	state ResumeEntry2 {
		entry $move_forward
	}
	state ResumeEntry3 {
		entry $displacement_out ! 0
	}
	state ResumeExit1 {
	}
	state ResumeExit2 {}
	state ResumeExit3 {}
	state Go_upEntry1 {
		entry $move_forward
	}
	state Go_upExit {}
	state Go_RightEntry1 {
		entry $turn ! Direction::right
	}
	state Go_RightEntry2 {
		entry $move_forward
	}
	state Go_RightEntry3 {
		entry $displacement_out ! 0
	}
	state Go_rightExit {		
	}
	state Go_downEntry1 {
		entry $turn!Direction::right
	}
	state Go_downEntry2 {
		entry $move_forward
	}
	state Go_downExit1 {
	}
	state Go_downExit2 {
		entry $turn!Direction::left
	}
	state Go_downExit3 {
		entry $move_forward
	}
	state Go_downExit4 {
		entry $displacement_out!0
	}
	state Go_right_again {
	}
	state CheckEnd {
	}
	state Check_battery {}
	state Check_batteryExit {
		entry $turn!Direction::left
	}
	
	state ReturnEntry1{
		entry $turn!Direction::left
	}
	state ReturnEntry2{
		entry $turn!Direction::left
	}
	state ReturnEntry3{
		entry $move_forward
	}
	state ReturnEntry4{
		entry $clean!false
	}
	state ReturnEntry5{
	}
	state DockEntry1 {
		entry $turn!Direction::left
	}
	state DockEntry2 {
		entry $move_forward
	}
	state DockEntry3 {}
	state Sleep {
		entry $stop
	}
	state SleepExit1 {
		entry $turn!Direction::left
	}
	state SleepExit2 {
		entry $turn!Direction::left
	}
	state SleepExit3 {
		entry $move_forward
	}		
	transition t0 {
		from i0 to ResumeEntry1
		action cycles = 0
	}
	
	transition tResumeEntry1 {
		from ResumeEntry1 to ResumeEntry2
		condition $turn_ack
	}
	transition tResumeEntry1exec {
		from ResumeEntry1 to ResumeEntry1
		exec
		condition not $turn_ack
	}
	
	transition tResumeEntry2 {
		from ResumeEntry2 to ResumeEntry3
		condition $move_forward_ack
	}
	transition tResumeEntry2exec {
		from ResumeEntry2 to ResumeEntry2
		exec
		condition not $move_forward_ack
	}
		
	transition tResumeEntry3 {
		from ResumeEntry3 to ResumeExit1
		condition $displacement_out_ack
	}
	transition tResumeEntry3exec {
		from ResumeEntry3 to ResumeEntry3
		exec
		condition not $displacement_out_ack
	}
	
	transition tResumeExit1 {
		from ResumeExit1
		to ResumeExit2
		condition $displacement_in?d /\ d >= cycles*2*nozzle
		action $displacement_in_ack; $turn ! Direction::left
	}
	transition tResumeExit1exec {
		from ResumeExit1
		to ResumeExit1
		exec
		condition not ($displacement_in?d /\ d >= cycles*2*nozzle)
	}
		
	transition tResumeExit2 {
		from ResumeExit2
		to ResumeExit3
		condition $turn_ack
		action $clean!true
	}
	transition tResumeExit2exec {
		from ResumeExit2
		to ResumeExit2
		exec
		condition not $turn_ack
		action $turn ! Direction::left
	}
	
	transition tResumeExit3 {
		from ResumeExit3
		to Go_upEntry1
		condition $clean_ack
	}
	transition tResumeExit3exec {
		from ResumeExit3
		to ResumeExit3
		exec
		condition not $clean_ack
	}
	
	transition tGoUpExec {
		from Go_upEntry1
		to Go_upEntry1
		exec
		condition not $move_forward_ack
	}
	
	transition tGoUp {
		from Go_upEntry1
		to Go_upExit
		condition $move_forward_ack
	}
	
	transition tGoUpExitExec {
		from Go_upExit
		to Go_upExit
		exec
		condition not ($ultrasonic?u /\ u >= cliff)
	}
	transition tGoUpExit {
		from Go_upExit
		to Go_RightEntry1
		condition $ultrasonic?u /\ u >= cliff
		action $ultrasonic_ack
	}
	transition tGo_RightEntry1Exec {
		from Go_RightEntry1
		to Go_RightEntry1
		exec
		condition not $turn_ack
	}
	transition tGo_RightEntry1 {
		from Go_RightEntry1
		to Go_RightEntry2
		condition $turn_ack
	}
	
	transition tGo_RightEntry2Exec {
		from Go_RightEntry2
		to Go_RightEntry2
		exec
		condition not $move_forward_ack
	}
	transition tGo_RightEntry2 {
		from Go_RightEntry2
		to Go_RightEntry3
		condition $move_forward_ack
	}
	
	transition tGo_RightEntry3Exec {
		from Go_RightEntry3
		to Go_RightEntry3
		exec
		condition not $displacement_out_ack
	}
	transition tGo_RightEntry3 {
		from Go_RightEntry3
		to Go_rightExit
		condition $displacement_out_ack
	}
	
	transition tGo_rightExitExec {
		from Go_rightExit
		to Go_rightExit
		exec
		condition not (($ultrasonic?u /\ u >= cliff) \/ ($displacement_in?d /\ d >= nozzle))
	}
	transition tGo_rightExit1 {
		from Go_rightExit
		to Go_downEntry1
		condition $ultrasonic?u /\ u >= cliff
		action $ultrasonic_ack
	}
	transition tGo_rightExit2 {
		from Go_rightExit
		to Go_downEntry1
		condition $displacement_in?d /\ d >= nozzle
		action $displacement_in_ack
	}
	
	transition tGo_downEntry1Exec {
		from Go_downEntry1
		to Go_downEntry1
		exec
		condition not $turn_ack
	}
	transition tGo_downEntry1 {
		from Go_downEntry1
		to Go_downEntry2
		condition $turn_ack
	}
	
	transition tGo_downEntry2Exec {
		from Go_downEntry2
		to Go_downEntry2
		exec
		condition not $move_forward_ack
	}
	transition tGo_downEntry2 {
		from Go_downEntry2
		to Go_downExit1
		condition $move_forward_ack
	}
	
	transition tGo_downExit1Exec {
		from Go_downExit1
		to Go_downExit1
		exec
		condition not ($ultrasonic?u /\ u>=cliff)
	}
	transition tGo_downExit1 {
		from Go_downExit1
		to Go_downExit2
		condition $ultrasonic?u /\ u>=cliff
		action $ultrasonic_ack
	}
	
	transition tGo_downExit2Exec {
		from Go_downExit2
		to Go_downExit2
		exec
		condition not $turn_ack
	}
	transition tGo_downExit2 {
		from Go_downExit2
		to Go_downExit3
		condition $turn_ack
	}
	
	transition tGo_downExit3Exec {
		from Go_downExit3
		to Go_downExit3
		exec
		condition not $move_forward_ack
	}
	transition tGo_downExit3 {
		from Go_downExit3
		to Go_downExit4
		condition $move_forward_ack
	}
	
	transition tGo_downExit4Exec {
		from Go_downExit4
		to Go_downExit4
		exec
		condition not $displacement_out_ack
	}
	transition tGo_downExit4 {
		from Go_downExit4
		to Go_right_again
		condition $displacement_out_ack
	}
	
	transition tGo_downExit5Exec {
		from Go_right_again
		to Go_right_again
		exec
		condition not $ultrasonic?u
	}
	transition tGo_downExit5_1 {
		from Go_right_again
		to CheckEnd
		condition $ultrasonic?u /\ u < cliff
		action $ultrasonic_ack
	}
	transition tGo_downExit5_2 {
		from Go_right_again
		to ReturnEntry1
		condition $ultrasonic?u /\ u >= cliff
		action $ultrasonic_ack; cycles = 0
	}
	
	transition tCheckEndExec {
		from CheckEnd
		to CheckEnd
		exec
		condition not $displacement_in?d
	}
	transition tCheckEnd1 {
		from CheckEnd
		to Go_right_again
		condition $displacement_in?d /\ d<nozzle
		action $displacement_in_ack
	}
	transition tCheckEnd2 {
		from CheckEnd
		to Check_battery
		condition $displacement_in?d /\ d>=nozzle
		action $displacement_in_ack; cycles = cycles+1
	}
	
	transition tCheckBatteryExec {
		from Check_battery
		to Check_battery
		exec
		condition not $battery_level?b
	}
	transition tCheckBattery1 {
		from Check_battery
		to Check_batteryExit
		condition $battery_level?b /\ b>battery_low
		action $battery_level_ack
	}
	transition tCheckBatery2 {
		from Check_battery
		to ReturnEntry1
		condition $battery_level?b /\ b<=battery_low
		action $battery_level_ack
	}
	
	transition tCheckBatteryExitExec {
		from Check_batteryExit
		to Check_batteryExit
		exec
		condition not $turn_ack
	}
	transition tCheckBatteryExit {
		from Check_batteryExit
		to Go_upEntry1
		condition $turn_ack
	}
	
	transition tReturnEntry1Exec {
		from ReturnEntry1
		to ReturnEntry1
		exec
		condition not $turn_ack
	}
	transition tReturnEntry1 {
		from ReturnEntry1
		to ReturnEntry2
		condition $turn_ack
	}
	
	transition tReturnEntry2Exec {
		from ReturnEntry2
		to ReturnEntry2
		exec
		condition not $turn_ack
	}
	transition tReturnEntry2 {
		from ReturnEntry2
		to ReturnEntry3
		condition $turn_ack
	}	
	
	transition tReturnEntry3Exec {
		from ReturnEntry3
		to ReturnEntry3
		exec
		condition not $move_forward_ack
	}
	transition tReturnEntry3 {
		from ReturnEntry3
		to ReturnEntry4
		condition $move_forward_ack
	}
	
	transition tReturnEntry4Exec {
		from ReturnEntry4
		to ReturnEntry4
		exec
		condition not $clean_ack
	}
	transition tReturnEntry4 {
		from ReturnEntry4
		to ReturnEntry5
		condition $clean_ack
	}
	
	transition tReturnEntry5 {
		from ReturnEntry5
		to DockEntry1
		condition $ultrasonic?u /\ u >= cliff
		action $ultrasonic_ack
	}
	transition tReturnEntry5Exec {
		from ReturnEntry5
		to ReturnEntry5
		exec
		condition not ($ultrasonic?u /\ u >= cliff)
	}
	
	transition tDockEntry1 {
		from DockEntry1
		to DockEntry2
		condition $turn_ack
	}
	transition tDockEntry1Exec {
		from DockEntry1
		to DockEntry1
		exec
		condition not $turn_ack
	}
	
	transition tDockEntry2 {
		from DockEntry2
		to DockEntry3
		condition $move_forward_ack
	}
	transition tDockEntry2Exec {
		from DockEntry2
		to DockEntry2
		exec
		condition not $move_forward_ack
	}
	
	transition tDockEntry3 {
		from DockEntry3
		to Sleep
		condition $charging
		action $charging_ack
	}
	transition tDockEntry3Exec {
		from DockEntry3
		to DockEntry3
		exec
		condition not $charging
	}
	
	transition tSleep {
		from Sleep
		to SleepExit1
		condition $stop_ack
		action wait(sleep_time)
	}
	transition tSleepExec {
		from Sleep
		to Sleep
		exec
		condition not $stop_ack
	}
	
	transition tSleepExit1 {
		from SleepExit1
		to SleepExit2
		condition $turn_ack
	}
	transition tSleepExit1Exec {
		from SleepExit1
		to SleepExit1
		exec
		condition not $turn_ack
	}

	transition tSleepExit2 {
		from SleepExit2
		to SleepExit3
		condition $turn_ack
	}
	transition tSleepExit2Exec {
		from SleepExit2
		to SleepExit2
		exec
		condition not $turn_ack
	}

	transition tSleepExit3 {
		from SleepExit3
		to ResumeEntry1
		condition $move_forward_ack
	}
	transition tSleepExit3Exec {
		from SleepExit3
		to SleepExit3
		exec
		condition not $move_forward_ack
	}
}

