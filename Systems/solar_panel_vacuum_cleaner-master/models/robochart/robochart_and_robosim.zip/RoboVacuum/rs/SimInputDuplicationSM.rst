controller SimInputDuplicationTest {
	cycleDef cycle == 1
	event i: TripleAxis

	event o1 : TripleAxis

	event o2 : TripleAxis
	
	sref main = SimInputDuplicationSM
	sref out = SimInputDuplicationOutput
	
	connection SimInputDuplicationTest on i to main on i
	connection main on o1 to out on o1
	connection main on o2 to out on o2
	connection out on o_ack1 to main on o_ack1
	connection out on o_ack2 to main on o_ack2
	connection out on vo1 to SimInputDuplicationTest on o1
	connection out on vo2 to SimInputDuplicationTest on o2
}
stm SimInputDuplicationSM {
	cycleDef cycle == 1
	var x: TripleAxis
	
	input context {
		event i: TripleAxis
		event o_ack1
		event o_ack2
	}
	output context {
		event o1: TripleAxis
		event o2: TripleAxis
		event i_ack
	}initial I
	state wait_input {
		
	}

	state wait_ack1 {
		
	}
	state wait_ack2 {
		
	}
	transition t0 {
		from I to wait_input
	}
	transition t1 {
		from wait_input to wait_input
		exec
		condition not $i 
	}
	transition t2 {
		from wait_input to wait_ack1
		condition $i?x
		action $i_ack; $o1.x
	}
	transition t8 {
		from wait_ack1 to wait_ack2
		condition $o_ack1
		action $o2.x
	}
	transition t4 {
		from wait_ack2 to wait_input
		condition $o_ack2
	}
	transition t7 {
		from wait_ack1 to wait_ack1
		exec
		condition not $o_ack1
		action $o1!x
	}
	transition t9 {
		from wait_ack2 to wait_ack2
		exec
		condition not $o_ack2
		action $o2!x
	}
}

stm SimInputDuplicationOutput {
	cycleDef cycle == 1
	var x: TripleAxis
	input context {
		event o1: TripleAxis
		event o2: TripleAxis
	}
	output context {
		event o_ack1
		event o_ack2
		event vo1: TripleAxis
		event vo2: TripleAxis
	}initial I
	state receive {}
	transition t0 {
		from I to receive
	}
	transition t1 {
		from receive to receive
		condition $o1?x
		action $o_ack1; exec; $vo1!x
	}
	transition t2 {
		from receive to receive
		condition $o2?x
		action $o_ack2; exec; $vo2!x
	}
	transition t3 {
		from receive to receive
		exec
		condition not $o1 /\ not $o2
	}
}

