interface SimPIDVariables {
	var prior_error : int
	var integral : int
	const kp : int
	const ki : int
	const kd : int
	var error : int
	var derivative : int
	var out : int
	const step : int
	var target_value : int
	var actual_value : int
	var old_target : int
}

stm SimPID {
	cycleDef cycle == 1
	input context {
		event target: int
		event actual: int
		event err_ack
	}
	output context {
		event err_output: int
		event target_ack
		event actual_ack
	}
	uses SimPIDVariables
	initial I
	state Wait_target {}
	state Wait_actual {}
	state Reset {
		entry prior_error = 0; integral = 0
	}
	state Update {
		entry error = actual_value-target_value; integral = integral+(error*step); derivative = floor((error-prior_error)/step); out = kp*error+ki*integral+kd*derivative; prior_error = error; $err_output!out
	}
	state Wait_err_ack {}
	transition t0 {
		from I to Wait_target
		action prior_error = 0; integral = 0
	}
	transition t1a {
		from Wait_target to Wait_actual
		condition $target?target_value /\ target_value == old_target
		action $target_ack
	}
	transition t1b {
		from Wait_target to Reset
		condition $target?target_value /\ target_value != old_target
		action $target_ack
	}
	transition t1exec {
		from Wait_target to Wait_target
		exec
		condition not $target?target_value
	}
	transition t2 {
		from Reset to Update
		condition $actual?actual_value
		action $actual_ack
	}
	transition t2exec {
		from Reset to Reset
		exec
		condition not $actual?actual_value 
	}
	transition t3 {
		from Wait_actual to Update
		condition $actual?actual_value
		action $actual_ack
	}
	transition t3exec {
		from Wait_actual to Wait_actual
		exec
		condition not $actual?actual_value
	}
	transition t4 {
		from Wait_err_ack to Wait_target
		condition $err_ack
		action old_target = target_value; wait(step)
	}
	transition t4exec {
		from Wait_err_ack to Wait_err_ack
		exec
		condition not $err_ack
	}
	transition t5 {
		from Update to Wait_err_ack
	}
	
}
