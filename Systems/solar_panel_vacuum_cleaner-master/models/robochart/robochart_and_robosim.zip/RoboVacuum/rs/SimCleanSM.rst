stm SimCleanSM {
	cycleDef cycle == 1
	input context {
		event clean: boolean
	}
	output context {
		requires CleaningOperations
		event clean_ack
	}
	const voltage: int
	var clean_var: boolean
	initial I
	state Dont_Clean {
		entry brush(0); vacuum(0)
	}
	state Clean {
		entry brush(voltage); vacuum(voltage)
	}
	transition t0 {
		from I to Dont_Clean
	}
	transition t1 {
		from Dont_Clean to Clean
		condition $clean?clean_var /\ clean_var == true
		action $clean_ack
	}
	transition t1exec {
		from Dont_Clean to Dont_Clean
		exec
		condition not ($clean?clean_var /\ clean_var == true)
	}
	transition t2 {
		from Clean to Dont_Clean
		condition $clean?clean_var /\ clean_var == false
		action $clean_ack
	}
	transition t2exec {
		from Clean to Clean
		exec
		condition not($clean?clean_var /\ clean_var == false)
	}
	
}