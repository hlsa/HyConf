stm SimDisplacementSM {
	cycleDef cycle == 1
	var d: int, speed: TripleAxis
	const t: int
	input context {
		event sp: TripleAxis
		event displacement_in: int
		
	event displacement_out_ack
	}
	output context {
		event displacement_out: int
		event displacement_in_ack
		event sp_ack
	}initial I
	junction J0
	state wait_input {
		
	}
	state update_displacement {
		entry d = d + speed.X*t
	}
	state wait_displacement_ack {
	}
	transition t0 {
		from I to J0
		action d = 0
	}
	transition t1 {
		from J0
		to wait_input
	}
	transition t2 {
		from wait_input
		to J0
		condition $displacement_in?d /\ d == 0
		action $displacement_in_ack
	}
	transition t2exec {
		from wait_input
		to wait_input
		exec
		condition not($displacement_in?d /\ d == 0) /\ not($sp?speed)
	}
	transition t3 {
		from wait_input
		to update_displacement
		condition $sp?speed
		action $sp_ack
	}
	transition t4 {
		from update_displacement
		to wait_displacement_ack
		action $displacement_out!d
	}
	transition t5 {
		from wait_displacement_ack
		to wait_input
		condition $displacement_out_ack
		action wait(t)
	}
	transition t5exec {
		from wait_displacement_ack
		to wait_displacement_ack
		exec
		condition not $displacement_out_ack
		action $displacement_out!d
	}
	
}

