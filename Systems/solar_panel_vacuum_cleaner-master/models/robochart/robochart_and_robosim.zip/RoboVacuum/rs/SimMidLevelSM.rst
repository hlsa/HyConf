interface MovementCommandsAck {
	event move_forward_ack
	event turn_ack
	event stop_ack
}

stm SimMidLevelSM {
	cycleDef cycle == 1
	input context {
		event speed_adjustment : int
		event angle_adjustment : int
		uses MovementCommands
		event target_speed_ack
		event target_angle_ack
	}
	output context {
		event target_speed : int
		event target_angle : int
		event speed_adjustment_ack
		event angle_adjustment_ack
		uses MovementCommandsAck
	}
	clock T
	const step : int
	uses MidVars
	requires MovementOperations
	
	initial i0
	
	transition t0 {
		from i0
		to GoUpEntry0
		action orientation = Orientation::up; lspeed = 0; rspeed = 0
	}
	
	state GoUpEntry0 {
		entry #T
	}
	transition tGoUpEntry0 {
		from GoUpEntry0
		to GoUpEntry1
	}
	state GoUpEntry1 {
		entry $target_speed ! climb_speed
	}
	transition tGoUpEntry1 {
		from GoUpEntry1
		to GoUpEntry2
		condition $target_speed_ack
	}
	transition tGoUpEntry1Exec {
		from GoUpEntry1
		to GoUpEntry1
		exec
		condition not $target_speed_ack
	}
	state GoUpEntry2 {}
	transition tGoUpEntry2 {
		from GoUpEntry2
		to GoUpEntry3
		condition $speed_adjustment ? speed_adj
		action $speed_adjustment_ack
	}
	transition tGoUpEntry2Exec {
		from GoUpEntry2
		to GoUpEntry2
		exec
		condition not $speed_adjustment ? speed_adj
	}
	state GoUpEntry3 {
		entry $target_angle	! forward_angle
	}
	transition tGoUpEntry3 {
		from GoUpEntry3
		to GoUpEntry4
		condition $target_angle_ack
	}
	transition tGoUpEntry3Exec {
		from GoUpEntry3
		to GoUpEntry3
		exec
		condition not $target_angle_ack
	}
	state GoUpEntry4 {}
	transition tGoUpEntry4 {
		from GoUpEntry4
		to GoUpEntry5
		condition $angle_adjustment ? angle_adj
		action $angle_adjustment_ack
	}
	transition tGoUpEntry4Exec {
		from GoUpEntry4
		to GoUpEntry4
		exec
		condition not $angle_adjustment ? angle_adj
	}
	state GoUpEntry5 {
		entry lspeed = lspeed - speed_adj - angle_adj ; rspeed = rspeed - speed_adj + angle_adj ; 
			  output_left_motor(lspeed) ; output_right_motor( rspeed)
	}
	transition tGoUpEntry5 {
		from GoUpEntry5
		to GoUpDuring
	}
	state GoUpDuring {}
	transition tGoUpDuringExec {
		from GoUpDuring
		to GoUpDuring
		exec
		condition not ($turn \/ $stop \/ since(T) >= step)
	}
	transition tGoUDuring0 {
		from GoUpDuring
		to GoUpEntry0
		condition since(T) >= step
	}
	transition tGoUpDuring1 {
		from GoUpDuring
		to TurnRightEntry0
		condition $turn?direction /\ direction == Direction::right
		action $turn_ack; orientation = turn_right(orientation); lspeed = stopsp; rspeed = stopsp
	}
	transition tGoUpDuring2 {
		from GoUpDuring
		to TurnLeftEntry0
		condition $turn?direction /\ direction == Direction::left
		action $turn_ack; orientation = turn_left(orientation); lspeed = stopsp; rspeed = stopsp
	}
	transition tGoUpDuring3 {
		from GoUpDuring
		to StopEntry0
		condition $stop
		action $stop_ack; lspeed = stopsp; rspeed = stopsp
	}
		
	state StopEntry0 {
		entry #T
	}
	transition tStopEntry0 {
		from StopEntry0
		to StopEntry1
	}
	state StopEntry1 {
		entry $target_speed ! turn_speed
	}
	transition tStopEntry1 {
		from StopEntry1
		to StopEntry2
		condition $target_speed_ack
	}
	transition tStopEntry1Exec {
		from StopEntry1
		to StopEntry1
		exec
		condition not $target_speed_ack
	}
	state StopEntry2 {}
	transition tStopEntry2 {
		from StopEntry2
		to StopEntry3
		condition $speed_adjustment ? speed_adj
		action $speed_adjustment_ack
	}
	transition tStopEntry2Exec {
		from StopEntry2
		to StopEntry2
		exec
		condition not $speed_adjustment ? speed_adj
	}
	state StopEntry3 {
		entry $target_angle ! forward_angle
	}
	transition tStopEntry3 {
		from StopEntry3
		to StopEntry4
		condition $target_angle_ack
	}
	transition tStopEntry3Exec {
		from StopEntry3
		to StopEntry3
		exec
		condition not $target_angle_ack
	}
	state StopEntry4 {
		
	}
	transition tStopEntry4 {
		from StopEntry4
		to StopEntry5
		condition $angle_adjustment ? angle_adj
		action $angle_adjustment_ack
	}
	transition tStopEntry4Exec {
		from StopEntry4
		to StopEntry4
		exec
		condition not $angle_adjustment ? angle_adj
	}
	state StopEntry5 {
		entry lspeed = lspeed - speed_adj -
		angle_adj ; rspeed = rspeed - speed_adj + angle_adj ; output_left_motor(
		lspeed) ; output_right_motor( rspeed)
	}
	transition tStopEntry5 {
		from StopEntry5
		to StopDuring
	}
	state StopDuring {}
	transition tStopDuringExec {
		from StopDuring
		to StopDuring
		exec
		condition not ($turn \/ since(T) >= step)
	}
	transition tStopDuring0 {
		from StopDuring
		to StopEntry0
		condition since(T) >= step
	}
	transition tStopDuring1 {
		from StopDuring
		to TurnRightEntry0
		condition $turn?direction /\ direction == Direction::right
		action $turn_ack; orientation = turn_right(orientation)
	}
	transition tStopDuring2 {
		from StopDuring
		to TurnLeftEntry0
		condition $turn?direction /\ direction == Direction::left
		action $turn_ack; orientation = turn_left(orientation)
	}
	
	state TurnRightEntry0 {
		entry #T
	}
	transition tTurnRightEntry0 {
		from TurnRightEntry0
		to TurnRightEntry1
	}
	state TurnRightEntry1 {
		entry $target_speed ! turn_speed
	}
	transition tTurnRightEntry1 {
		from TurnRightEntry1
		to TurnRightEntry2
		condition $target_speed_ack
	}
	transition tTurnRightEntry1Exec {
		from TurnRightEntry1
		to TurnRightEntry1
		exec
		condition not $target_speed_ack
	}
	state TurnRightEntry2 {}
	transition tTurnRightEntry2 {
		from TurnRightEntry2
		to TurnRightEntry3
		condition $speed_adjustment ? speed_adj
		action $speed_adjustment_ack
	}
	transition tTurnRightEntry2Exec {
		from TurnRightEntry2
		to TurnRightEntry2
		exec
		condition not $speed_adjustment ? speed_adj
	}
	state TurnRightEntry3 {
		entry $target_angle ! right_angle
	}
	transition tTurnRightEntry3 {
		from TurnRightEntry3
		to TurnRightEntry4
		condition $target_angle_ack
	}
	transition tTurnRightEntry3Exec {
		from TurnRightEntry3
		to TurnRightEntry3
		exec
		condition not $target_angle_ack
	}
	state TurnRightEntry4 {
		
	}
	transition tTurnRightEntry4 {
		from TurnRightEntry4
		to TurnRightEntry5
		condition $angle_adjustment ? angle_adj
		action $angle_adjustment_ack
	}
	transition tTurnRightEntry4Exec {
		from TurnRightEntry4
		to TurnRightEntry4
		exec
		condition not $angle_adjustment ? angle_adj
	}
	state TurnRightEntry5 {
		entry lspeed = lspeed - speed_adj -	angle_adj ; rspeed = rspeed - speed_adj + angle_adj ; 
		output_left_motor(lspeed) ; output_right_motor( rspeed)
	}
	transition tTurnRightEntry5 {
		from TurnRightEntry5
		to TurnRightDuring
	}
	state TurnRightDuring {}
	transition tTurnRightDuringExec {
		from TurnRightDuring
		to TurnRightDuring
		exec
		condition not ($turn \/ $move_forward \/ since(T) >= step)
	}
	
	transition tTurnRightDuring0 {
		from TurnRightDuring
		to TurnRightEntry0
		condition since(T) >= step
	}
	transition tTurnRightDuring1 {
		from TurnRightDuring
		to TurnRightEntry0
		condition $turn?direction /\ direction == Direction::right
		action $turn_ack; orientation = turn_right(orientation)
	}
	transition tTurnRightDuring2 {
		from TurnRightDuring
		to GoDownEntry0
		condition $move_forward /\ orientation == Orientation::down
		action $move_forward_ack; lspeed = movesp; rspeed = movesp
	}
	transition tTurnRightDuring3 {
		from TurnRightDuring
		to GoSideEntry0
		condition $move_forward /\ (orientation == Orientation::left \/ orientation == Orientation::right)
		action $move_forward_ack; rspeed = movesp; lspeed = movesp
	}
	transition tTurnRightDuring4 {
		from TurnRightDuring
		to TurnLeftEntry0
		condition $turn?direction /\ direction == Direction::left
		action $turn_ack; orientation = turn_left(orientation)
	}
	transition tTurnRightDuring5 {
		from TurnRightDuring
		to GoUpEntry0
		condition $move_forward /\ orientation == Orientation::up
		action $move_forward_ack; lspeed = movesp; rspeed = movesp
	}
	
	state TurnLeftEntry0 {
		entry #T
	}
	transition tTurnLeftEntry0 {
		from TurnLeftEntry0
		to TurnLeftEntry1
	}
	state TurnLeftEntry1 {
		entry $target_speed ! turn_speed
	}
	transition tTurnLeftEntry1 {
		from TurnLeftEntry1
		to TurnLeftEntry2
		condition $target_speed_ack
	}
	transition tTurnLeftEntry1Exec {
		from TurnLeftEntry1
		to TurnLeftEntry1
		exec
		condition not $target_speed_ack
	}
	state TurnLeftEntry2 {
	transition tTurnLeftEntry2 {
		from TurnLeftEntry2
		to TurnLeftEntry3
		condition $speed_adjustment ? speed_adj
		action $speed_adjustment_ack
		}
	}
	transition tTurnLeftEntry2Exec {
		from TurnLeftEntry2
		to TurnLeftEntry2
		exec
		condition not $speed_adjustment ? speed_adj
	}
	state TurnLeftEntry3 {
		entry $target_angle ! left_angle
	}
	transition tTurnLeftEntry3 {
		from TurnLeftEntry3
		to TurnLeftEntry4
		condition $target_angle_ack
	}
	transition tTurnLeftEntry3Exec {
		from TurnLeftEntry3
		to TurnLeftEntry3
		exec
		condition not $target_angle_ack
	}
	state TurnLeftEntry4 {}
	transition tTurnLeftEntry4 {
		from TurnLeftEntry4
		to TurnLeftEntry5
		condition $angle_adjustment ? angle_adj
		action $angle_adjustment_ack
	}
	transition tTurnLeftEntry4Exec {
		from TurnLeftEntry4
		to TurnLeftEntry4
		exec
		condition not $angle_adjustment ? angle_adj
	}
	state TurnLeftEntry5 {
		entry lspeed = lspeed - speed_adj -	angle_adj ; rspeed = rspeed - speed_adj + angle_adj ; 
			output_left_motor(lspeed) ; output_right_motor(rspeed)
	}
	transition tTurnLeftEntry5 {
		from TurnLeftEntry5
		to TurnLeftDuring
	}
	state TurnLeftDuring {}
	transition tTurnLeftDuringExec {
		from TurnLeftDuring
		to TurnLeftDuring
		exec
		condition not (since(T) >= step \/ $turn \/ $move_forward)
	}
	transition tTurnLeftDuring0 {
		from TurnLeftDuring
		to TurnLeftEntry0
		condition since(T) >= step
	}
	transition tTurnLeftDuring1 {
		from TurnLeftDuring
		to TurnLeftEntry0
		condition $turn?direction /\ direction == Direction::left
		action $turn_ack; orientation = turn_left(orientation)
	}
	transition tTurnLeftDuring2 {
		from TurnLeftDuring
		to GoDownEntry0
		condition $move_forward /\ orientation == Orientation::down
		action $move_forward_ack; lspeed = movesp; rspeed = movesp
	}
	transition tTurnLeftDuring3 {
		from TurnLeftDuring
		to GoSideEntry0
		condition $move_forward /\ (orientation == Orientation::left \/ orientation == Orientation::right)
		action $move_forward_ack; rspeed = movesp; lspeed = movesp
	}
	transition tTurnLeftDuring4 {
		from TurnLeftDuring
		to TurnRightEntry0
		condition $turn?direction /\ direction == Direction::right
		action $turn_ack; orientation = turn_right(orientation)
	}
	transition tTurnLeftDuring5 {
		from TurnLeftDuring
		to GoUpEntry0
		condition $move_forward /\ orientation == Orientation::up
		action $move_forward_ack; lspeed = movesp; rspeed = movesp
	}
	
	state GoSideEntry0 {
		entry #T
	}
	transition tGoSideEntry0 {
		from GoSideEntry0
		to GoSideEntry1
	}
	state GoSideEntry1 {
		entry $target_speed!side_speed
	}
	transition tGoSideEntry1 {
		from GoSideEntry1
		to GoSideEntry2
		condition $target_speed_ack
	}
	transition tGoSideEntry1Exec {
		from GoSideEntry1
		to GoSideEntry1
		exec
		condition not $target_speed_ack
	}
	state GoSideEntry2 {}
	transition tGoSideEntry2 {
		from GoSideEntry2
		to GoSideEntry3
		condition $speed_adjustment?speed_adj
		action $speed_adjustment_ack
	}
	transition tGoSideEntry2Exec {
		from GoSideEntry2
		to GoSideEntry2
		exec
		condition not $speed_adjustment?speed_adj
	}
	state GoSideEntry3 {
		entry $target_angle!forward_angle
	}
	transition tGoSideEntry3 {
		from GoSideEntry3
		to GoSideEntry4
		condition $target_angle_ack
	}
	transition tGoSideEntry3Exec {
		from GoSideEntry3
		to GoSideEntry3
		exec
		condition not $target_angle_ack
	}
	state GoSideEntry4 {}
	transition tGoSideEntry4 {
		from GoSideEntry4
		to GoSideEntry5
		condition $angle_adjustment?angle_adj
		action $angle_adjustment_ack
	}
	transition tGoSideEntry4Exec {
		from GoSideEntry4
		to GoSideEntry4
		exec
		condition not $angle_adjustment?angle_adj
	}
	state GoSideEntry5 {
		entry lspeed = lspeed - speed_adj -
		angle_adj ; rspeed = rspeed - speed_adj + angle_adj ; output_left_motor(
		lspeed) ; output_right_motor( rspeed)
	}
	transition tGoSideEntry5 {
		from GoSideEntry5
		to GoSideDuring
	}
	state GoSideDuring {}
	transition tGoSideDuringExec {
		from GoSideDuring
		to GoSideDuring
		exec
		condition not (since(T) >= step \/ $turn \/ $stop)
	}
	transition tGoSideDuring0 {
		from GoSideDuring
		to GoSideEntry0
		condition since(T) >= step
	}
	transition tGoSideDuring1 {
		from GoSideDuring
		to TurnRightEntry0
		condition $turn?direction /\ direction == Direction::right
		action $turn_ack; orientation = turn_right(orientation); lspeed = stopsp; rspeed = stopsp
	}
	transition tGoSideDuring2 {
		from GoSideDuring
		to TurnLeftEntry0
		condition $turn?direction /\ direction == Direction::left
		action $turn_ack; orientation = turn_left(orientation); lspeed = stopsp; rspeed = stopsp
	}
	transition tGoSideDuring3 {
		from GoSideDuring
		to StopEntry0
		condition $stop
		action $stop_ack; lspeed = stopsp; rspeed = stopsp
	}
	
	state GoDownEntry0 {
		entry #T
	}
	transition tGoDownEntry0 {
		from GoDownEntry0
		to GoDownEntry1
	}
	state GoDownEntry1 {
		entry $target_speed ! descent_speed
	}
	transition tGoDownEntry1 {
		from GoDownEntry1
		to GoDownEntry2
		condition $target_speed_ack
	}
	transition tGoDownEntry1Exec {
		from GoDownEntry1
		to GoDownEntry1
		exec
		condition not $target_speed_ack
	}
	state GoDownEntry2 {}
	transition tGoDownEntry2 {
		from GoDownEntry2
		to GoDownEntry3
		condition $speed_adjustment ? speed_adj
		action $speed_adjustment_ack
	}
	transition tGoDownEntry2Exec {
		from GoDownEntry2
		to GoDownEntry2
		exec
		condition not $speed_adjustment ? speed_adj
	}
	state GoDownEntry3 {
		entry $target_angle ! forward_angle
	}
	transition tGoDownEntry3 {
		from GoDownEntry3
		to GoDownEntry4
		condition $target_angle_ack
	}
	transition tGoDownEntry3Exec {
		from GoDownEntry3
		to GoDownEntry3
		exec
		condition not $target_angle_ack
	}
	state GoDownEntry4 {}
	transition tGoDownEntry4 {
		from GoDownEntry4
		to GoDownEntry5
		condition $angle_adjustment ? angle_adj
		action $angle_adjustment_ack
	}
	transition tGoDownEntry4Exec {
		from GoDownEntry4
		to GoDownEntry4
		exec
		condition not $angle_adjustment ? angle_adj
	}
	state GoDownEntry5 {
		entry lspeed = lspeed - speed_adj - angle_adj ; rspeed = rspeed - speed_adj + angle_adj ;
		output_left_motor( lspeed) ; output_right_motor( rspeed)
	}
	transition tGoDownEntry5 {
		from GoDownEntry5
		to GoDownDuring
	}
	state GoDownDuring {}
	transition tGoDownDuring0 {
		from GoDownDuring
		to GoDownDuring
		exec
		condition not (since(T)>=step \/ $turn \/ $stop)
	}
	transition tGoDownDuringExec {
		from GoDownDuring
		to GoDownEntry0
		condition since(T) >= step
	}
	transition tGoDownDuring1 {
		from GoDownDuring
		to TurnRightEntry0
		condition $turn?direction /\ direction == Direction::right
		action $turn_ack; orientation = turn_right(orientation); lspeed = stopsp; rspeed = stopsp
	}
	transition tGoDownDuring2 {
		from GoDownDuring
		to TurnLeftEntry0
		condition $turn?direction /\ direction == Direction::left
		action $turn_ack; orientation = turn_left(orientation); lspeed = stopsp; rspeed = stopsp
	}
	transition tGoDownDuring3 {
		from GoDownDuring
		to StopEntry0
		condition $stop
		action $stop_ack; lspeed = stopsp; rspeed = stopsp
	}
}

