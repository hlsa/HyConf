stm SimAngularSpeedSM {
	cycleDef cycle == 1
	input context {
		event acc_l: TripleAxis
		event acc_r: TripleAxis
		event angle_ack
	}
	output context {
		event angle: int
		event acc_l_ack
		event acc_r_ack
	}
	var al: TripleAxis, ar: TripleAxis
	var speed: int, turn_angle: real
	const t: int, acc_distance: int
	var direction: Direction
	initial I
	state wait_input{}
	state wait_al{}
	state wait_ar{}
	state update_value{
		entry turn_angle = turn_angle + sqrt(abs(al.Y-ar.Y)/acc_distance)*t
	}
	state wait_angle_ack{}
	transition t0 {
		from I to wait_input
		action turn_angle = 0
	}
	transition t1 {
		from wait_input to wait_al
		condition $acc_r?ar
		action $acc_r_ack
	}
	transition t1exec {
		from wait_input to wait_input
		exec
		condition not $acc_l /\ not $acc_r
	}
	transition t2 {
		from wait_al
		to update_value
		condition $acc_l?al
		action $acc_l_ack
	}
	transition t2exec {
		from wait_al to wait_al
		exec
		condition not $acc_l
	}
	transition t3 {
		from wait_input to wait_ar
		condition $acc_l?al
		action $acc_l_ack
	}
	transition t4 {
		from wait_ar to update_value
		condition $acc_r?ar
		action $acc_r_ack
	}
	transition t4exec {
		from wait_ar to wait_ar
		exec
		condition not $acc_r
	}
	transition t5 {
		from update_value
		to wait_angle_ack
		action $angle!(get_sign(al.Y)*floor(turn_angle))
	}
	transition t6 {
		from wait_angle_ack to wait_input
		condition $angle_ack
		action wait(t)
	}
	transition t6exec {
		from wait_angle_ack to wait_angle_ack
		exec
		condition not $angle_ack
		action $angle!(get_sign(al.Y)*floor(turn_angle))
	}
}