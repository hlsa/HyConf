stm SimLinearSpeedSM {
	cycleDef cycle == 1
	input context {
		event speed_l: TripleAxis
		event speed_r: TripleAxis
		event ls_ack
	}
	output context {
		event linear_speed: int
		event speed_l_ack
		event speed_r_ack
	}
	var spl: TripleAxis, spr: TripleAxis
	initial I
	state wait_input{}
	state wait_left{}
	state wait_right{}
	state send_output{}
	state wait_output_ack{}
	transition t0 {
		from I to wait_input
	}
	transition t1 {
		from wait_input to wait_left
		condition $speed_r?spr
		action $speed_r_ack
	}
	transition t1exec {
		from wait_input to wait_input
		exec
		condition not $speed_l /\ not $speed_r
	}
	transition t2 {
		from wait_left
		to send_output
		condition $speed_l?spl
		action $speed_l_ack
	}
	transition t2exec {
		from wait_left to wait_left
		exec
		condition not $speed_l
	}
	transition t3 {
		from wait_input to wait_right
		condition $speed_l?spl
		action $speed_l_ack
	}
	transition t4 {
		from wait_right to send_output
		condition $speed_r?spr
		action $speed_r_ack
	}
	transition t4exec {
		from wait_right to wait_right
		exec
		condition not $speed_r
	}
	transition t5 {
		from send_output
		to wait_output_ack
		action $linear_speed!get_linear_speed(spl.Z,spr.Z)
	}
	transition t6 {
		from wait_output_ack to wait_input
		condition $ls_ack
	}
	transition t6exec {
		from wait_output_ack to wait_output_ack
		exec
		condition not $ls_ack
		action $linear_speed!get_linear_speed(spl.Z,spr.Z)
	}
}