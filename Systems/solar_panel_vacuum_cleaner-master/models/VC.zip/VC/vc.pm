package  VacuumCleaner
pmodel VacuumCleaner{				
		link containment{
			pose { x=0.0 y=0.0 z=0.0325 roll=0.0 pitch=0.0 yaw=0.0}
			link Cylinder{
				body containment{
					body Cylinder{
						inertial information{ 
							mass 3.927e-02
						}	
						cylinder (radius=0.05, length=0.005)
					}
				}				
				joint containment {
					pose { x=0.0 y=-0.0225 z=0.014 roll=0.0 pitch=0.0 yaw=0.0}
					joint LeftHinge{
								annotation Revolute  {
									axis=Axis{
										xyz = (|0,1,0|)	
									}
								}
						flexibly connected to LeftWheel
					}
				}
				joint containment {
					pose { x=0.0 y=0.0225 z=0.014 roll=0.0 pitch=0.0 yaw=0.0}
					joint RightHinge{
								annotation Revolute  {
									axis=Axis{
										xyz = (|0,1,0|)	
									}
								}
						flexibly connected to RightWheel
					}
				}
 				joint containment {
					pose { x=0.02 y=0.0 z=0.01 roll=0.0 pitch=0.0 yaw=0.0}
					jref FrontSpherical=Spherical{	
						flexibly connected to FrontCaster
					}
				}
				joint containment {
					pose { x=-0.02 y=0.0 z=0.01 roll=0.0 pitch=0.0 yaw=0.0}
					jref BackSpherical=Spherical{						
						flexibly connected to BackCaster
					}
				}
 				sensor containment{
					pose { x=-0.05 y=0.0 z=0.03 roll=0.0 pitch=3.1415 yaw=0.0}
					sref Proximity = IR
				}
 				sensor containment{
					pose { x=0.0 y=-0.05 z=0.03 roll=0.0 pitch=3.1415 yaw=0.0}
					sref acc_left = ACC
				}
				sensor containment{
					pose { x=0.0 y=0.05 z=0.03 roll=0.0 pitch=3.1415 yaw=0.0}
					sref acc_right = ACC
				}																								
			}
		}
  		link containment{
			pose { x=0.03 y=0.0 z=0.01 roll=0.0 pitch=0.0 yaw=0.0}
			link FrontCaster{
				body containment{
					body FrontCaster{
						sphere (radius=0.01)
					}
				}
			}
		}
		link containment{
			pose { x=-0.03 y=0.0 z=0.01 roll=0.0 pitch=0.0 yaw=0.0}
			link BackCaster{
				body containment{
					body BackCaster{
						sphere (radius=0.01)
					}
				}
			}
		}							
 		link containment {
			pose { x=0.0 y=0.0225 z=0.014 roll=1.57 pitch=0.0 yaw=0.0}
			link LeftWheel{
				body containment{
					body LeftWheel{
						cylinder (radius=0.014, length=0.005)
					}
				}
			}
		}
		link containment {
			pose { x=0.0 y=-0.0225 z=0.014 roll=1.57 pitch=0.0 yaw=0.0}
			link RightWheel{
				body containment{
					body RightWheel{
						cylinder (radius=0.014, length=0.005)
					}
				}			
			}
		}
 		link containment{
			pose { x=0.0 y=0.0 z=0.02 roll=0.0 pitch=0.0 yaw=0.0}
			link Cuboid{
				fixed to Cylinder
				body containment{
					body Cuboid{
						inertial information{ 
							mass 3.200e-02
						}						
						box (length=0.04, width=0.04, height=0.02)
					}
				}									
			}
		}				
}

sensor IR {
	annotation Logical_camera{
		basic=SensorAnnotation { always_on = true update_rate=1.0}
		near = 0.02
		far = 0.3
		aspect_ratio=0.0
		horizontal_fov=0.0
	}	
}

sensor ACC {
	annotation Logical_camera{
		basic=SensorAnnotation { always_on = true update_rate=1.0}
		near = 0.02
		far = 0.3
		aspect_ratio=0.0
		horizontal_fov=0.0
	}		
}

joint Spherical {
}